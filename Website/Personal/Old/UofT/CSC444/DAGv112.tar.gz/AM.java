//package am;

import java.io.*;
import java.util.*;
import java.util.StringTokenizer;


/**
 * @author AMS 
 */
public class AM implements ArtifactManegment
{

	// Holds a list of all Artifacts
	public static List list;
	
    private CFM cfm_object;
	private MP mp_object;
	

	/**
	 * Constructor for AM, makes a call to initMovObjects() to init the artifact list
	 */
	public AM()  {
		this.list = initMovObjects();
	}
	
	/**
	 * Constructor for AM
	 * @param list to initialize the artifact list
	 */
	public AM(ArrayList list) {
		this.list = list;
	}

    public void setCFM (CFM cfm_object ) {
	   this.cfm_object = cfm_object;
    }

     public void setMP (MP mp_object ) {
	this.mp_object = mp_object;

	 if (this.mp_object == null) 
		System.out.println("********mp_object null******");
     }

	
	/**
	 * @see am.ArtifactManegment#getName(UniqueId)
	 */
	public String getName(UniqueId id)
	{
		Artifact art;

		for (Iterator iter = list.iterator(); iter.hasNext();)
		{
			art = (Artifact) iter.next();
			if (id.getUid() == art.getObject().getUid())
			{
				return art.getShortName();
			}
		}
//		throw new Exception();
		return null;
	}

	/**
	 * @see am.ArtifactManegment#getDescription(UniqueId)
	 */
	public String getDescription(UniqueId id) throws Exception
	{
		Artifact art;

		for (Iterator iter = list.iterator(); iter.hasNext();)
		{
			art = (Artifact) iter.next();
			if (id.getUid() == art.getObject().getUid())
			{
				return art.getDescription();
			}
		}
		throw new Exception();
	}

	/**
	 * The list with all the artifacts is provided in artlist.txt, which should be created by MP group.
	 * There is a simple convention which should be used when specifying the artifacts.
	 * List all artifacts one per line, in the following order:
	 * type%id(long)%description(str)%shortName(str)%location(long)%strength(int)%usage(int)%action1#action2#...%
	 * if the artifact is a tool it should include usageClass and usageObjects specify them as follows and append them at the
	 * end of the previous line %uClass1#uClass2#uClass3#uClass4%uObj1#uObj2#uObj3...
	 * 
	 * @return List an arrayList of all artifacts specified in artifactlist file
	 */
	public List initMovObjects()
	{

		String str;
		List alist = new ArrayList();

		try
		{
			BufferedReader in = new BufferedReader(new FileReader("artlist.txt"));

			while ((str = in.readLine()) != null)
			{
				StringTokenizer reader = new StringTokenizer(str, "%");

				String type = reader.nextToken();
				long uId = Integer.valueOf(reader.nextToken()).longValue();
				String desc = reader.nextToken();
				String sName = reader.nextToken();
				long location = Integer.valueOf(reader.nextToken()).longValue();
				int strenght = Integer.valueOf(reader.nextToken()).intValue();
				int usage = Integer.valueOf(reader.nextToken()).intValue();

				List actions = new ArrayList();

				StringTokenizer actionTocken = new StringTokenizer(reader.nextToken(), "#");

				// init actions list
				while (actionTocken.hasMoreTokens())
				{
					actions.add(actionTocken.nextToken().trim());
				}

				if (type.equalsIgnoreCase("tool"))
				{
					List usageClass = new ArrayList();
					List usageObjects = new ArrayList();

					String tmp;

					// init usageClass list
					StringTokenizer uClass = new StringTokenizer(reader.nextToken(), "#");
					while (uClass.hasMoreTokens())
					{
						tmp = uClass.nextToken();
						if (tmp.equalsIgnoreCase("null"))
						{
							usageClass = null;
						} else
						{
							usageClass.add(tmp);
						}
					}

					// init usageObjects list
					StringTokenizer uObject = new StringTokenizer(reader.nextToken(), "#");
					while (uObject.hasMoreTokens())
					{
						tmp = uObject.nextToken();
						if (tmp.equalsIgnoreCase("null"))
						{
							usageObjects = null;
						} else
						{
							usageObjects.add(tmp);
						}
					}

					//<stub>
					if (usageClass != null)
					{
//						for (Iterator it = usageClass.iterator();it.hasNext(););
//							System.out.println(it.next().toString());
					}

					if (usageObjects != null)
					{
//						for (Iterator it = usageObjects.iterator();it.hasNext(););
//							System.out.println(it.next().toString());
					}

					System.out.println();
					// </stub>

					alist.add(
						new Tool(
							new UniqueId(uId, 'a'),
							desc,
							sName,
							new UniqueId(location, 'r'),
							strenght,
							usage,
							actions,
							usageClass,
							usageObjects));

				} else
				{
					if (type.equalsIgnoreCase("w"))
					{
						alist.add(
							new Weapon(
								new UniqueId(uId, 'a'),
								desc,
								sName,
								new UniqueId(location, 'r'),
								strenght,
								usage,
								actions));
					} else
						if (type.equalsIgnoreCase("t"))
						{
							alist.add(
								new Treasure(
									new UniqueId(uId, 'a'),
									desc,
									sName,
									new UniqueId(location, 'r'),
									strenght,
									usage,
									actions));
						} else
							if (type.equalsIgnoreCase("f"))
							{
								alist.add(
									new Food(
										new UniqueId(uId, 'a'),
										desc,
										sName,
										new UniqueId(location, 'r'),
										strenght,
										usage,
										actions));
							} else
								if (type == "g")
								{
									alist.add(
										new Thing(
											new UniqueId(uId, 'a'),
											desc,
											sName,
											new UniqueId(location, 'r'),
											strenght,
											usage,
											actions));
								}
				}
			} // while
			in.close();
		} catch (IOException e)
		{
		}

		// <stub>
		//		System.out.println("list size: " + alist.size());
		//
		//		for (Iterator it = alist.iterator(); it.hasNext();)
		//		{
		//			System.out.println(((Artifact) it.next()).getDescription());
		//		}
		//		
		// </stub>

		// list = alist;

	  	// mp_object.initialize((List)alist);

		return alist;
	}
 
 	
	/**
	 * @see am.ArtifactManegment#artifactPlacementChecker(List)
	 */
	public boolean artifactPlacementChecker(List artList)
	{
		//		An artifact placement checker: Given a list of artifacts in a room, checks that all placement 
		// 	constraints on those artifacts are obeyed
		//     Possible artifacts(Weapon, tool, Food, Thing, Treasure)
		//		This is unnecessary method for AM since MP group should worry about object placement
		//		The following objects can be placed anywhere: Weapon, Food, Thing and Treasure
		//		The only restriction is for the tool of type key
		
		// 	assumption: every room has a number, in increasing order as the the player supposed to progress
		//		through the game, ex start room is 1 and last room of that level is N, Then the door number to that 
		//		room corresponds to to the room number. Also the key number should be the same as the door it 
		//		operates on.
		// 
		//		thus if the tool's id is greater then the location id of where it is placed it returns false. As you can see
		//		it is a really stupid way to implement since it also does not make sence to check all artifacts and return
		//		false if only one artifact fails. The best thing to do is make sure that the placement is done correctly in 
		//		Mapping part where it should have been done in the first place.
		for(Iterator iter = artList.iterator(); iter.hasNext(); ) {
			Artifact art = (Artifact)iter.next();
			
			if(getArtifactType(art.getObject()).equals("tool")) {
				if(art.getLocation().getUid() >= art.getObject().getUid()) {
					return false;
				}			
			}		
		}
		
	
		return true;
	}

	/**
	 * @see am.ArtifactManegment#artifactActionCheck(UniqueId, String)
	 */
	public boolean artifactActionCheck(UniqueId id, String action) throws Exception
	{
	
		long tmpId = id.getUid();

		for (Iterator iter = list.iterator(); iter.hasNext();)
		{
			Artifact art = (Artifact) iter.next();

			if (tmpId == art.getObject().getUid())
			{
				for (Iterator i = art.getActions().iterator(); i.hasNext();)
				{
					if (action.toLowerCase().equals(((String)i.next()).toLowerCase()))
					{
						return true;
					}
				}
				return false;
			}
		}
		//artifact does not exist	
		throw new Exception();
	}

	/**
	 * @see am.ArtifactManegment#artifactActionUpdate(UniqueId, String)
	 */
	public boolean artifactActionUpdate(UniqueId id, String Action) throws Exception
	{
		//This method is for food only?
		long tmpId = id.getUid();

		for (Iterator iter = list.iterator(); iter.hasNext();)
		{
			Artifact art = (Artifact) iter.next();

			if (tmpId == art.getObject().getUid() && art.getUsage() > 0)
			{
				if (art.getUsage() == 1)
				{
					//food destoried
					art.setUsage(0);
					list.remove(art); //remove from the main list
					return true;
				} else
				{ //decrement usage by 1
					art.setUsage(art.getUsage() - 1);
					return false;
				}
			} else //it is an artifact with usage = -1 
				{
				return false;
			}
		}
		//artifact does not exist	
		throw new Exception();
	}

	/**
	 * @see am.ArtifactManegment#setDescription(UniqueId, String)
	 */
	public void setDescription(UniqueId id, String newDescriptioin) throws Exception
	{

		List tmpList = new ArrayList();
		Artifact art;

		for (Iterator iter = list.iterator(); iter.hasNext();)
		{
			art = (Artifact) iter.next();

			if (id.getUid() == art.getObject().getUid())
			{
				art.setDescription(newDescriptioin);
			}

			tmpList.add(art);
		}
		list = tmpList;
	}

	/**
	 * @see am.ArtifactManegment#listAllArtifactsActions()
	 */
	public List listAllArtifactsActions()
	{
		List tmpList = new ArrayList();

		for (Iterator i = list.iterator(); i.hasNext();)
		{
			Artifact art = (Artifact) i.next();
            

			for (Iterator j = (Iterator) art.getActions().iterator(); j.hasNext();)
			{
				tmpList.add(j.next());
			}
		}
		return tmpList;
	}

	/**
	 * @see am.ArtifactManegment#toolActionCheck(UniqueId, String, UniqueId)
	 */
	public boolean toolActionCheck(UniqueId tool, String action, UniqueId object) throws Exception
	{
		//to ckeck wether the action is in both obiect's action list.
		//Ex, "open" should be in both "key" and "door" or "locks"

		//objects for tool operation must be in our main list??

		List toolActionList = new ArrayList();
		List objActionList = new ArrayList();
		List tmp = new ArrayList();
		String toolAction, objAction;
		Artifact art1, art2;
		Iterator iter, iter2;

		for (iter = list.iterator(); iter.hasNext();)
		{
			art1 = (Artifact) iter.next();

			if (tool.getUid() == art1.getObject().getUid())
			{
				//tool exists
				toolActionList = art1.getActions();

				for (iter2 = toolActionList.iterator(); iter2.hasNext();)
				{
					toolAction = (String) iter2.next();

					if (toolAction.equals(action))
					{
						//action exist in tool action list
						break;
					}
				}
			}
			//else tool DNE
		}

		for (iter = list.iterator(); iter.hasNext();)
		{
			art2 = (Artifact) iter.next();

			if (object.getUid() == art2.getObject().getUid())
			{
				//obj exists
				objActionList = art2.getActions();

				for (iter2 = objActionList.iterator(); iter2.hasNext();)
				{
					objAction = (String) iter2.next();

					if (objAction.equals(action))
					{
						//action exists in object action list
						return true;
					}
				}
			}
			//else obj NDE
		}
		return false;
	}

	/**
	 * @see am.ArtifactManegment#toolActionDescribe(UniqueId, String, UniqueId)
	 */
	public String toolActionDescribe(UniqueId tool, String action, UniqueId object) throws Exception
	{

		if (!tool.isArtifact() || !object.isArtifact())
		{
			throw new Exception();
		} else
		{
			return getName(tool) + " " + action + " " + getName(object);
		}
	}


	/**
	 * @see am.ArtifactManegment#getLocation(UniqueId)
	 */
	public UniqueId getLocation(UniqueId ID)
	{
		Artifact art;

		for (Iterator iter = list.iterator(); iter.hasNext();)
		{
			art = (Artifact) iter.next();

			if (ID.getUid() == art.getObject().getUid())
			{
				return art.getLocation();
			}
		}
		return null;
	}
	
	/**
	 * @see am.ArtifactManegment#setLocation(UniqueId, UniqueId)
	 */
	public void setLocation(UniqueId artId, UniqueId roomId)
	{
		List tmpList = new ArrayList();
		Artifact art;

		for (Iterator iter = list.iterator(); iter.hasNext();)
		{
			art = (Artifact) iter.next();

			if (artId.getUid() == art.getObject().getUid())
			{
				art.setLocation(roomId);

			}
			tmpList.add(art);
		}
		list = tmpList;
	}


	/**
	 * @see am.ArtifactManegment#getCurrentList()
	 */
	public List getCurrentList()
	{
		return list;
	}

	/**
	 * @see am.ArtifactManegment#setCurrentList(List)
	 */
	public void setCurrentList(List artifactList)
	{
		this.list = artifactList;
	}

	/**
	 * @see am.ArtifactManegment#getStrength(UniqueId)
	 */
	public int getStrength(UniqueId uid)
	{
		Artifact art;
		
		for (Iterator iter = list.iterator(); iter.hasNext();)
		{
			art = (Artifact) iter.next();
			if (uid.getUid() == art.getObject().getUid())
			{
				return art.getStrength();
			}
		}

		return -99;
	}

	/**
	 **@see am.ArtifactManegment#getArtifactType(UniqueId)
	 */
	public String getArtifactType(UniqueId artifactId)
	{
		Artifact art;
		for (Iterator iter = list.iterator(); iter.hasNext();)
		{
			art = (Artifact) iter.next();

			if (artifactId.getUid() == art.getObject().getUid())
			{
				if (art instanceof Weapon)
				{
					return new String("weapon");
				} else
					if (art instanceof Treasure)
					{
						return new String("treasure");
					} else
						if (art instanceof Food)
						{
							return new String("food");
						} else
							if (art instanceof Tool)
							{
								return new String("tool");
							} else
								if (art instanceof Thing)
								{
									return new String("thing");
								}
			}
		}
		return null;
	}

 	public String getWeaponVerb(UniqueId weapon_used) {

		// make sure weapon is an artifact type
		if (weapon_used.getType() == 'a' || weapon_used.getType() == 'A') {

			long tmpId = weapon_used.getUid();

			// find the artifact
			for (Iterator iter = list.iterator(); iter.hasNext(); ) {
				Artifact art = (Artifact) iter.next();

				// return first verb associated with action
				if (tmpId == art.getObject().getUid()) {
					if (art.getActions().isEmpty() != true) { 
						return (String)art.getActions().get(1);
					}
				}
			}
		} 
		return null;
	}

	public static void main(String[] args)
	{
		AM am = new AM();

		List l = am.initMovObjects();

		//		for (Iterator it = l.iterator(); it.hasNext();) {
		//			System.out.println(((Artifact) it.next()).getDescription());
		//		}
		//
		//		try {
		//			System.out.println("\n" + am.getDescription(new UniqueId(2, 'a')) + "\n");
		//		} catch (Exception e) {
		//		}
		//
		//		try {
		//			am.setDescription(new UniqueId(2, 'a'), "description changed for Orange");
		//		} catch (Exception e) {
		//		}
		//
		//		try {
		//			System.out.println(am.getDescription(new UniqueId(2, 'a')));
		//		} catch (Exception e) {
		//		}
		//		System.out.println();
		//		for (Iterator it = l.iterator(); it.hasNext();) {
		//			System.out.println(((Artifact) it.next()).getDescription());
		//		}
		//
		//		System.out.println("list size: "+l.size());
		//
		//
		//		try {
		//			System.out.println(
		//				am.toolActionDescribe(new UniqueId(5, 'a'), "hit", new UniqueId(1, 'a')));
		//		} catch (Exception e) {
		//		}

	}
}
