import  java.util.*;

public interface AM_interface{
	
	// provide artifact's uid and return its shortname
	public String getShortName(UniqueId art_uid);	

	// provide artifact's uid and return its full description 
	// change the name to getDescription
//	public String getDescription(UniqueId art_uid);
		// We have used the definition in the java docs here because it matches
		//	the definition in game specs
	public String getDescription(String name);

	// create a new artifact list inside the AM class and it return a list of moveable object's uid
	public List initialArtifactList();


	// provide List of artifact, return a boolean 
//	public boolean artifactPlacementChecker(List artifactList);

	// provide artifact's uid and a action verb, return true if this action is valid for this artifact
	public boolean artifactAndActionChecker(UniqueId uid, String action);	

	// provide actionWord(string), artifact's uid and update of the attribute
	// return true if the artifact is destoryed(usage =0 )
	// Since in the new CSC444 spec, actionUpdate() need to return error code..
	// as a result we need int instead boolean
	public int artifactUpdate(UniqueId art_uid, String actionWord);
	
	// update the description of an artifact
	// provide the new description and replace the description in given artifact
//	public void updateDesc(UniqueId uid, Stirng new_desc);

	// return a list of actions(String) that is valid of all artifacts
//	public List listAllAction();
		// used the name in the javadocs here because it makes more sense
    public List listAllActions();

	// provide an action uid, object uid and an action uid, return boolean if the combination is valid
	public boolean toolActionChecker(UniqueId tool_uid, UniqueId obj_uid, String action);

	// provide an action uid, object uid and an action uid, return String of description and also update the 
	// tools
//	public String toolActionDesriber(UniqueId tool_uid, UniqueId obj_uid, String action);


	// Extra method
   
	// provide artifact's uid and return the location's uid
//	public UniqueId getLocation(UniqueId art_uid);

	// provide articfact�s uid and new_room id, and set the Location,
//	public void setLocation(UniqueId artifact_uid, UniqueId room_uid);

	// optional, since according to the specification document, saving should
	// be finished by DM. However, logical it is more reasonable to finish in the 
	// other interface. Cos DM should not have any gameObject, it had better only
	// have uid list. But if we put save under DM, DM will need some addition function
	// to get the objectlist from those interface (room, artifact and creature list)
	// and then save it
	//
	// save the artifact list to a file
	public void save(String filename);
	public void restore(String filename);

	// if the save/restore function is not implement, 
	// a "getting artifact list" function need to be added
	// in order to let the DM to save the all data
//	public List getCurrentList();
//	public void setCurrentList( List artifactList);
		// we have no knowledge of these objects so we can't save them

	// get the strength of the articfact
//	public int getStrength(UniqueId uid);

	// provide the artifact uid and return the type of the artifact 
	// for example 'w' stands for weapon, 't' stands for tools, 't' stands for treasure
//	public char getArtifactType(UniqueId artifactId);

	// DM will call this function to pass the MP object
	public void setMP(MP mp_object);

	// DM will call this function to pass the CFM object
	public void setCFM(CFM cfm_object);	

}
