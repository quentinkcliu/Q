//package am;

import java.util.*;

/**
 * @author Igor Keizner
 */
public class Artifact extends MoveableObject 
{
	private List actions;
	private int usage;
	
	/**
	 * Constructor for Artifact.
	 */
	public Artifact() 
	{
		super();
		
		this.actions = null;
		this.usage = 0;
	}

	/**
	 * Constructor for Artifact.
	 * @param new_uid
	 * @param description
	 * @param shortName
	 * @param location
	 * @param strength
	 */
	public Artifact(UniqueId new_uid,String description,String shortName,UniqueId location,int strength,int usage, List actions) 
	{
		super(new_uid, description, shortName, location, strength);
		
		this.actions = actions;
		this.usage = usage;
	}
	/**
	 * Returns the actions.
	 * @return List
	 */
	public List getActions() 
	{
		return actions;
	}

	/**
	 * Returns the usage.
	 * @return List
	 */
	public int getUsage() 
	{
		return usage;
	}

	/**
	 * Sets the actions.
	 * @param actions The actions to set
	 */
	public void setActions(List actions) 
	{
		this.actions = actions;
	}

	/**
	 * Sets the usage.
	 * @param usage The usage to set
	 */
	public void setUsage(int usage) 
	{
		this.usage = usage;
	}
}
