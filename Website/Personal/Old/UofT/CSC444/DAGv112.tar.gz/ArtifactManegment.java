//package am;

import java.util.*;

/**
 * @author AMS
 */
public interface ArtifactManegment
{

	/**
	 * Given the unique id of a moveable object (creature or artifact), returns the short name ofthe thing.
	 * 
	 * Method getName.
	 * @param id UniqueId of the artifact
	 * @return String name of the artifact
	 * @throws Exception Thrown if artifact now found
	 */

	public String getName(UniqueId id) throws Exception;
	/**
	 * Given the unique name of a moveable object (creature or artifact), returns a fulldescription of that object.
	 * 
	 * Method getDescription.
	 * @param id UniqueId of the artifact
	 * @return String description of the artifact
	 * @throws Exception Thrown if artifact now found
	 */

	public String getDescription(UniqueId id) throws Exception;
	
	/**
	 * Creates an initial list of moveable objects (creatures and artifacts), and returns a list oftheir unique ids.
	 * 
	 * Method initMovObjects.
	 * @return List list of artifacts initialized from a list
	 */
	public List initMovObjects();

	/**
	 * Returns true if an artifact is in its proper location according to all placement constraints.
	 * 
	 * Method artifactPlacementChecker.
	 * @param artList list of artifacts
	 * @return boolean true if -ALL- tools are placed in the proper order, false if atleast one fails
	 */
	public boolean artifactPlacementChecker(List artList);

	/**
	 * Given the unique name of an artifact, and an action word, returns true or falsedepending on whether the action is valid for that artifact.
	 * 
	 * Method artifactActionCheck.
	 * @param id Unique id of the artifact
	 * @param action action word
	 * @return boolean true if the action is valid for the artifact false otherwise
	 * @throws Exception if artifact does not exist
	 */
	public boolean artifactActionCheck(UniqueId id, String action) throws Exception;

	/**
	 * Given the unique id of an artifact, and an action word, updates the artifact�s attributes. Returns true if the artifact was destroyed, false otherwise.
	 * 
	 * Method artifactActionUpdate.
	 * @param id UniqueId of the artifact
	 * @param Action action to be performed on the object
	 * @return boolean true if artifact was destroyed false otherwise
	 * @throws Exception Thrown if artifact is not found
	 */
	public boolean artifactActionUpdate(UniqueId id, String Action) throws Exception;

	/**
	 * Given the unique id of an artifact, and a description, changes the description of the artifact to the given description.
	 * 
	 * Method setDescription.
	 * @param id UniqueId of the artifact which needs to have its description updated
	 * @param new Descriptioin new description for the artifact
	 * @throws Exception Thrown if artifact is not found
	 */
	public void setDescription(UniqueId id, String newDescriptioin) throws Exception;

	/**
	 * Returns a complete list of all action words used for all artifacts included in the game,including those action words that apply to whole classes of artifacts.
	 * 
	 * Method listAllArtifactsActions.
	 * @return List ArrayList of all artifacts
	 */
	public List listAllArtifactsActions();

	/**
	 * Given a tool and an action and an object id, checks that the action is valid for that tool on that object.
	 * 
	 * Method toolActionCheck.
	 * @param tool UniqueId of the tool
	 * @param action String action word
	 * @param object UniqueId of an object on which the tool needs to operate on
	 * @return boolean returns true if operational false if the tool is not operational on the object
	 * @throws Exception Thrown if artifact is not found
	 */
	public boolean toolActionCheck(UniqueId tool, String action, UniqueId object) throws Exception;

	/**
	 * Given a tool and an action and an object, returns a description of the result of using that tool on that object.
	 * 
	 * Method toolActionDescribe.
	 * @param tool UniqueId of the tool
	 * @param action an action word
	 * @param object UniqueId of the object
	 * @return String a string description of the tool applied on an object
	 * @throws Exception Thrown if artifact is not found
	 */
	public String toolActionDescribe(UniqueId tool, String action, UniqueId object)
		throws Exception;

	// Extra methods
	


    /**    
      * Given a list of artifacts, sets artifact list to the given list.    
      *     
      * Method setCurrentList.    
      * @param artifactList  Given list of the artifacts  
      */    
     public void setCurrentList(List artifactList);    
    
  
     /**    
      * Given the unique id of an artifact, returns strength of that artifact  
      *     
      * Method getStrength.    
      * @param uid  UniqueId of the artifact   
      * @return int  Strength of the artifact  
      */    
     public int getStrength(UniqueId uid);    
    
  
   /** Given the unique id of an artifact, returns location of that artifact.    
      *      
      * Method getLocation.    
      * @param art_uid  UnqieueId of the artifact  
      * @return UniqueId  UniqueId of the room the artifact is in  
      */    
     public UniqueId getLocation(UniqueId art_uid);    
    
  
     /**    
      * Given the unique id of an artifact and unique if of a room, sets location of the   
      *  specified artifact to specified room.    
      *     
      * Method setLocation.    
      * @param artifact_uid  UnqieueId of the artifact  
      * @param room_uid  UnqieueId of the room  
      */    
     public void setLocation(UniqueId artifact_uid, UniqueId room_uid);    
    
     /**  Returns the list of all artifacts  
      *      
      * Method getCurrentList.    
      * @return List  List of all artifacts  
      */    
     public List getCurrentList();  

	/**
	 * Returns type of an artifact specified by unique id.
	 * 
	 * Method getArtifactType.
	 * @param artifactId UniqueId of the artifact
	 * @return String a string description of the artifact(tool,food,treasure...) or if not artifact returns null;
	 */
	public String getArtifactType(UniqueId artifactId);

	// DM will call this function to pass the MP object
	public void setMP(MP mp_object);

	// DM will call this function to pass the CFM object
	public void setCFM(CFM cfm_object);	


}
