/*==============================================================================
= Course: CSC444F - Software Engineering I                                     =
= Date: November 14, 2002                                                      =
= Group Members: Brian Dennis (dennis@ecf.utoronto.ca)                         =
=                Eric Reppo (reppo@ecf.utoronto.ca)                            =
=                S. Jalal Shah (shahs@ecf.utoronto.ca)                         =
=                Shawn D'Souza (dsouzas@ecf.utoronto.ca)                       =
= CSCI: Creature and Fight Management (CFM)                                    =
= Website:  http://www.ecf.utoronto.ca/~dennis/csc444f                         =
==============================================================================*/

/*==============================================================================
=                                CFM Class                                     =
==============================================================================*/

import java.util.*;

/**
 * <b>Course:</b> CSC444F - Software Engineering I <br>
 * <b>Group Members:</b> <br>
 * Brian Dennis (dennis@ecf.utoronto.ca) <br>
 * Eric Reppo (reppo@ecf.utoronto.ca) <br>
 * S. Jalal Shah (shahs@ecf.utoronto.ca) <br>
 * Shawn D'Souza (dsouzas@ecf.utoronto.ca) <br>
 * <b>CSCI:</b> Creature and Fight Management (CFM) <br>
 * <b>Website:</b> http://www.ecf.utoronto.ca/~dennis/csc444f <br> <br>
 *
 * This data abstraction keeps track of all creatures in the game, including the
 * player, and manages fight sequences.  All methods involving the Creature,
 * Monster and Player objects are controlled via methods in this data abstraction.
 */

public class CFM implements CFM_interface{
    
    public static LinkedList creatures = new LinkedList();
    private static UniqueId player_id;
    private static boolean initialized = false;
    private AM am_object;
	private MP mp_object;
	private static int idNumber = 1;
	
    public void setAM (AM am_object ) {
	   this.am_object = am_object;
    }

     public void setMP (MP mp_object ) {
		this.mp_object = mp_object;
     }
	 
	/**
     * A player object is created with default attributes, short_name = "Player" and
     * description = "Small wimpy elf", and the CFM class is initialized.
     *
     * @throws  CFMAlreadyInitializedException If the CFM class has already been initialized.
     */
    
         /*
          * Date: October 22, 2002
          * Programmers: Eric and Shawn
          * Description: Error Checking, changed return type to boolean
          */
    
        /*
         * Date: October 30, 2002
         * Programmers: Brian
         * Description: Changed return type to void and added throw exception
         */
    
         /*
          * Date: October 1, 2002
          * Programmers: Brian
          * Description: Created method
          */
    public void initCFM(){
        if (initialized == true) {
			return;
        }
        //Create player
        Player player = new Player("Player", "Small wimpy elf.");
        player_id = player.getObject();
        creatures.add(player);
        initialized = true;
    }
    /**
     * A player object is created with the specified short_name and description. The CFM class is initialized.
     *
     * @param short_name    The short name of the player
     * @param description    A description of the player
     * @throws  CFMNotInitializedException If the CFM class has not been initialized.
     */
    
    public void initCFM(String short_name, String description){
        if (initialized == true) {
            return;
        }
        if((short_name==null)||(description==null)||
        (short_name.length()==0)||(description.length()==0)){
            //throw exception
        }
        //Create player
        Player player = new Player(description, short_name);
        player_id = player.getObject();
        creatures.add(player);
        initialized = true;
    }
    public List initialCreatureList(){
	  Random rand = new Random();
	  int randint;
	  
	  randint = rand.nextInt();
	  randint = randint % 10;   // at most ten creatures
	  randint = 10;
	  initCFM();
	  for (int i =0; i< randint; i++)
	    {
		  createMonster();
		}		
	   
	   if (mp_object == null)
	     System.out.println ("Mp is null");

	   mp_object.initialize(creatures);

	   return creatures;	  
	}
    /**
     * A monster is created with default attributes for short_name and description.  Strength, motility and predilection assigned randomly
     *
     * @return   The ID of the newly created monster
     * @throws  CFMNotInitializedException If the CFM class has not been initialized.
     */
    
       
    public UniqueId createMonster(){
		Monster new_monster;
		Random rand = new Random();
		int prob;
        if (initialized == false) {
 			return null;
        }
	
		prob = Math.abs(rand.nextInt()%10);

// ========================================
// if I take out this statement, then creatures not random, why?
System.out.print(prob+" "); 
// ===============================
		switch(prob) {
			case 0:
	        new_monster = new Monster("Ogre", "A regular ogre.");
			break;
			case 1:
			new_monster = new Monster("Elf", "A small elf");
			break;
			case 2:
			new_monster = new Monster("Cyclopse","a one eyed creature");
			break;
			case 3:
			new_monster = new Monster("Bear","big black bear");
			break;
			case 4:
			new_monster = new Monster("Vampire","blood sucking bat");
			break;
			case 5:
			new_monster = new Monster("T-Rex","an extinct creature");
			break;
			case 6:
			new_monster = new Monster("Witch","a small person with magic");
			break;
			case 7:
			new_monster = new Monster("Socerer","a guy with lost of magic");
			break;
			case 8:
			new_monster = new Monster("Zombie","the walking dead");
			break;
			case 9:
			new_monster = new Monster("IncredibleHulk","Big green guy");
			break;
			default:
			new_monster = new Monster("Frankenstien", "The Legend");
			break;
		}
		UniqueId temp = new UniqueId(idNumber++, 'c');
		new_monster.setUid(temp);
        creatures.add(new_monster);
        return  new_monster.getObject();
    }
    
    /**
     * A monster is created with specified attributes.  Strength,motility and predilection are assigned randomly
     *
     * @param short_name    The short name of the monster
     * @param description    A description of the monster
     * @return   The ID of the newly created monster, -1 if the parameters are not valid
     * @throws  CFMNotInitializedException If the CFM class has not been initialized.
     */
    
    public UniqueId createMonster(String short_name, String description) throws CFMNotInitializedException {
        if (initialized == false) {
            throw new CFMNotInitializedException();
        }
        else if (short_name == null || description == null||
        (short_name.length()==0)||(description.length()==0)) {
            return null;
        }
        else{
            Monster new_monster = new Monster(short_name, description);
            creatures.add(new_monster);
            return new_monster.getObject();
        }
    }
    
    /**
     * A monster is created with specified attributes. Strength and predilection are assigned randomly
     * @param short_name    The short name of the monster
     * @param description    A description of the monster
     * @param motility    The motility of the monster (valid motility range 0-100)
     * @return   The ID of the newly created monster, -1 if the parameters are not valid
     * @throws  CFMNotInitializedException If the CFM class has not been initialized.
     */
    
    public UniqueId createMonster(String short_name, String description, int motility) throws CFMNotInitializedException {
        if (initialized == false) {
            throw new CFMNotInitializedException();
        }
        else if (short_name == null || description == null||
        (short_name.length()==0)||description.length()==0||
        motility<0||motility>100) {
            return null;
        }
        else{
            Monster new_monster = new Monster(short_name, description, motility);
            creatures.add(new_monster);
            return new_monster.getObject();
        }
    }
    
    /**
     * A monster is created with specified attributes. Motility is assigned randomly
     * @param short_name    The short name of the monster
     * @param description    A description of the monster
     * @param strength    The strength of the monster (valid strength range 1-100)
     * @param predilection    The predilection of the monster (valid predilection range 0-100)
     * @return   The ID of the newly created monster, -1 if the parameters are not valid
     * @throws  CFMNotInitializedException If the CFM class has not been initialized.
     */
    
    public UniqueId createMonster(String short_name, String description, int strength, int predilection) throws CFMNotInitializedException {
        if (initialized == false) {
            throw new CFMNotInitializedException();
        }
        else if (short_name == null || description == null||
        (short_name.length()==0)||description.length()==0||
        predilection<0||predilection>100||
        strength<=0||strength>100){
            return null;
        }
        else{
            Monster new_monster = new Monster(short_name, description, strength, predilection);
            creatures.add(new_monster);
            return new_monster.getObject();
        }
    }
    
    /**
     * A monster is created with specified attributes.
     * @param short_name    The short name of the monster
     * @param description    A description of the monster
     * @param strength    The strength of the monster (valid strength range 1-100)
     * @param predilection    The predilection of the monster (valid predilection range 0-100)
     * @param motility    The motility of the monster (valid motility range 0-100)
     * @return   The ID of the newly created monster, -1 if the parameters are not valid
     * @throws  CFMNotInitializedException If the CFM class has not been initialized.
     */
    
    public UniqueId createMonster(String short_name, String description, int strength, int predilection, int motility) throws CFMNotInitializedException {
        if (initialized == false) {
            throw new CFMNotInitializedException();
        }
        else if (short_name == null || description == null||
        (short_name.length()==0)||description.length()==0||
        predilection<0||predilection>100||
        motility<0||motility>100||
        strength<=0||strength>100){
            return null;
        }
        else{
            Monster new_monster = new Monster(short_name, description, strength, predilection, motility);
            creatures.add(new_monster);
            return new_monster.getObject();
        }
    }
    
    /**
     * Gets the description of the specified creature
     *
     * @param creature_id    The id of the desired creature
     * @return       A String representing the description of the creature
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
    public String getCreatureDescription(UniqueId creature_id) throws CFMCreatureDoesNotExistException, CFMNotInitializedException {
        Creature creature = (Creature) findCreature(creature_id);
        return creature.getDescription();
    }
    
    /**
     * Gets the description short name of the specified creature
     * @param creature_id    The id of the desired creature
     * @return       A String representing the short name of the creature
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
         /*
          * Date: October 5, 2002
          * Programmers: Brian
          * Description: Created method
          */
    public String getShortName(UniqueId creature_id) {
        Creature creature = (Creature) findCreature(creature_id);
        return creature.getShortName();
    }
    
    /**
     * Gets the location of the specified creature
     * @param creature_id    The id of the desired creature
     * @return       An int representing the unique ID of the room the creature is in
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
    public UniqueId getLocation(UniqueId creature_id){
        Creature creature = (Creature) findCreature(creature_id);

		if( creature !=null){	
	        return creature.getLocation();
		}
		else
			return null;
    }
    
    /**
     * Sets the location (room) of the specified creature, does not actually add the creature to the list of creatures in the room
     * @param creature_id    The id of the desired creature
     * @param room_id    The unique id of room
     * @return   True if the parameter is valid and the location is set, false otherwise
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
    public boolean setLocation(UniqueId creature_id, UniqueId room_id) {
        if (room_id.getUid() <= 0) {
            return false;
        }
        Creature creature = (Creature) findCreature(creature_id);
        creature.setLocation(room_id);
        return true;
    }
    
    /**
     * Sets predilection of specified monster to 100
     * @param monster_id    The id of the monster to be made angry
     * @return       True is returned if the monster_id is a valid monster and the monster was made angry, false otherwise
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */

    public boolean makeMonsterAngry(UniqueId monster_id){
        if (monster_id.getUid() == player_id.getUid()) {
            return false;
        }
        Monster monster = (Monster) findCreature(monster_id);
        monster.makeAngry();
        return true;
    }
    
    /**
     * modifies strength of specified creature
     * @param creature_id    The id of the creature
     * @param Delta    The amount by which to change the strength of the creature
     * @return       True if the monster is still alive after the strength modification, false otherwise
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */

    public boolean modifyCreatureStrength(UniqueId creature_id, int Delta) throws CFMCreatureDoesNotExistException, CFMNotInitializedException {
        Creature creature = findCreature(creature_id);
        return creature.modifyStrength(Delta);
    }
    /**
     * modifies points of player
     * @param Delta    The amount by which to change the points of the player
     * @return   The new point total
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */

    public int modifyPlayerPoints(int delta) throws CFMCreatureDoesNotExistException, CFMNotInitializedException {
        Player player = (Player) findCreature(player_id);
        return player.modifyPoints(delta);
    }
    /**
     * gets points of player
     * @return   The point total of the player
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */

    public int point_score(){
        Player player = (Player) findCreature(player_id);
        return player.getPoints();
    }
    /**
     * sets points of player to specified value
     * @param points    The desired point total for the player
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */


    public void setScore(int points){
        Player player = (Player) findCreature(player_id);
        player.setPoints(points);
    }
    
    /**
     * Tests if the specified creature is alive
     * @param creature_id    The id of the creature
     * @return   True if creature is alive, false otherwise
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    

    public boolean isCreatureAlive(UniqueId creature_id){
        Creature creature = findCreature(creature_id);
        return creature.isAlive();
    }
    
    /**
     * Returns a list of weapons wielded by the specified creature
     * @param creature_id    The id of the creature
     * @return   A List containing all the weapon ids of the creature
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
         /*
          * Date: October 5, 2002
          * Programmers: Brian
          * Description: Created method
          */
    public List getWeaponsWielded(UniqueId creature_id) throws CFMCreatureDoesNotExistException, CFMNotInitializedException {
        Creature creature = findCreature(creature_id);
        return creature.getWeaponsWielded();
    }
    
    /**
     * Returns a list of artifacts possessed by the specified creature
     * @param creature_id    The id of the creature
     * @return   A List containing all the artifact ids of the creature
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
         /*
          * Date: October 5, 2002
          * Programmers: Brian
          * Description: Created method
          */
    public List getArtifact(UniqueId creature_id){
        Creature creature = findCreature(creature_id);
        return creature.getArtifacts();
    }
    
    /**
     * Determines which monsters attack the player and/or each other based on predilection and updates the strengths of affected monsters/player accordingly.
     * @param current_room_id    The id of the room the creature is currently in
     * @return   A list of strings describing the result of each fight that occurred in the room
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
         /*
          * Date: October 30, 2002
          * Programmers: Brian
          * Description: Fixed a few bugs
          */

         /*
          * Date: October 5, 2002
          * Programmers: Brian
          * Description: Created method
          */
    public String monsterAttacker(UniqueId current_room_id){
        
        // Get a list of creatures in the room
        List creature_ids =  mp_object.getCreatureList(current_room_id);
        String fight_description = new String();
        UniqueId creature_id, victim_id;
		int random_num;
        Monster monster, victim;
        Player player;
        
        // Check if room contains any creatures
        if (creature_ids != null && creature_ids.size() > 0) {
            
            // Find the player
            player = (Player) findCreature(player_id);
            // Remove the player from the list of creatures in the room
            creature_ids.remove(player_id);
            
                /* Examine each monster in the room and determine if
                they will attack the player without being provoked */
                for (int index = 0; index <= creature_ids.size()-1; index++) {
                    // Check if the player is still alive
                    if (!player.isAlive()) {
                        break;
                    }
                    // Find the monster
                    monster = (Monster) findCreature(( (UniqueId)creature_ids.get(index)));
                    // Check if a monster is alive
                    if (monster.isAlive()) {
                        // Generate a random number between 1 and 100
                        random_num = (int) (Math.floor(Math.random() * 99) + 1);
                        // Check if the monster will attack the player
                        if (random_num <= monster.getPredilection()) {
                           
						fight_description += (attack(monster.getObject(), player_id));
                        } else if (creature_ids.size() > 1) {
                              for (int index2 = 0; index2 <= creature_ids.size()-1; index2++) {
                                  // Generate a random number between 1 and 100
                                  random_num = (int) (Math.floor(Math.random() * 99) + 1);
                                  // Check if monster will attack another monster
                                  if (random_num <= monster.getPredilection()) {
                                     //  Find the victim monster that will be attacked  
                                     victim_id = (UniqueId) creature_ids.get(index2);
                                     victim = (Monster) findCreature(victim_id);
                                        if (victim_id.getUid() !=monster.getObject().getUid() && victim.isAlive()) {
                                           // Return description of fight
                                          
											fight_description += (attack(monster.getObject(), victim_id));
                                           break;
                                        }
                                  }
                              }
                        }
                    }
                }
        
        }
        return fight_description;
    }
    
    /**
     * Determines which monsters attack the player and/or each other based on predilection.  Updates the strengths of affected monsters/player accordingly.
     * @param current_room_id    The id of the room the creature is currently in
     * @return   An array of strings describing the result of each fight that occurred in the room
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
         /*
          * Date: October 5, 2002
          * Programmers: Brian
          * Description: Created method
          */
    public String MonstersAttack_Array(UniqueId current_room_id) throws CFMCreatureDoesNotExistException, CFMNotInitializedException {
        return monsterAttacker(current_room_id);
    }
    
    /**
     * Determines the result of the player attacking the monster with its currently wielded weapon
     * @param monster_id    The id of the monster to be attacked by the player
     * @return   A list describing the result of the attack
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */

         /*
          * Date: October 30, 2002
          * Programmers: Brian
          * Description: Fixed a bug
          */
    
         /*
          * Date: October 5, 2002
          * Programmers: Brian
          * Description: Created method
          */
    public String PlayerAttackMonster(UniqueId monster_id) throws CFMCreatureDoesNotExistException, CFMNotInitializedException {
        Monster monster = (Monster) findCreature(monster_id);
        Player player = (Player) findCreature(player_id);
        
        if (player.isAlive() && monster.isAlive()) {
            monster.makeAngry();
            return attack(player_id, monster_id);
        } else {
            return null;
        }
        
    }
    
        
    /**
     * Determines which monsters follow the player from the previous room to the present room
     * @param previous_room_id    The room the player just left
     * @param current_room_id    The room the player is in
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */

         /*
          * Date: October 30, 2002
          * Programmers: Brian
          * Description: Fixed a few bugs
          */
    
         /*
          * Date: October 10, 2002
          * Programmers: Brian
          * Description: Created method
          */

    public List monsterChase(UniqueId previous_room_id, UniqueId current_room_id) {
        
        // Get a list of creatures in the room
        List creature_ids = mp_object.getCreatureList(previous_room_id);
		List followingCreatures = new LinkedList();
        int random_num;
		UniqueId creature_id;
        Monster monster;
        
        // Check if any creatures were in previous room
        if (creature_ids != null && creature_ids.size() > 0) {
            /* Examine each monster in the room and determine if
            they have been attacked by the player and if so, will they chase
            the player to the next room */
            
            /* If for some reason the player is still in the previous room,
            remove the player from the list of creatures in the room */
            creature_ids.remove(player_id);
            
            for (int index = 0; index <= creature_ids.size()-1; index++) {
                // Find the creature
                monster = (Monster) findCreature((UniqueId)creature_ids.get(index));
                // Check if the Mosnter is alive
                if (monster.isAlive()) {
                    // Check if the creature has been attacked by the player
                    if (monster.getPredilection() == 100) {
                        // Generate a random number between 1 and 100
                        random_num = (int) (Math.floor(Math.random() * 99) + 1);
                        /* Compare the creatures motility to a random number
                        to see if the creature chases the player */
                        if (random_num <= monster.getMotility()) {
                            // Creature chases player
                           mp_object.removeMoveableObj(monster.getLocation(),monster.getObject().getType(),monster.getObject());
                           mp_object.addMoveableObj(current_room_id,monster.getObject().getType(),monster.getObject());
						   followingCreatures.add(monster.getObject());
                        }
                    }
                }
            }
        }
        return followingCreatures;
    }
    
    /**
     * Adds an artifact to the specified creature
     * @param creature_id    The id of the creature
     * @param artifact_id    The artifact id of the artifact to be added
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
         /*
          * Date: October 10, 2002
          * Programmers: Brian
          * Description: Created method
          */
    public void addArtifact(UniqueId creature_id, UniqueId artifact_id)  {
        Creature creature = findCreature(creature_id);
        creature.addArtifact((int)artifact_id.getUid());
        mp_object.removeMoveableObj(creature.getLocation(),creature.getObject().getType(),artifact_id);
    }
    
    /**
     * Removes an artifact from the specified creature
     * @param creature_id    The id of the creature
     * @param artifact_id    The artifact id of the artifact to be removed
     * @return   True if artifact removal occurred successfully (creature found, artifact possessed), false otherwise
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
         /*
          * Date: October 10, 2002
          * Programmers: Brian
          * Description: Created method
          */
    public void removeArtifact(UniqueId creature_id, UniqueId artifact_id){
        Creature creature = findCreature(creature_id);
        creature.removeArtifact(artifact_id,mp_object);
		return ;
    }
    
    /**
     * Sets the weilded artifact of the creature to the specified weapon
     * @param creature_id    The id of the creature
     * @param artifact_id    The artifact id of the weapon to be removed
     * @return   True if the artifact was wielded (creature found and artifact wielded), false otherwise
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
         /*
          * Date: October 10, 2002
          * Programmers: Brian
          * Description: Created method
          */
    public boolean wieldArtifact(UniqueId creature_id, UniqueId artifact_id) {
        Creature creature = findCreature(creature_id);
        return creature.wieldArtifact((int)artifact_id.getUid());
    }
    
    public void wield(UniqueId weaponId){
		UniqueId player = new UniqueId (0,'c');
		this.wieldArtifact(player,weaponId);
		return;
	}
    /**
     * Removes the monster specified from the creature list
     * @param monster_id    The id of the monster
     * @return   True if the monster was found and removed, false otherwize
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
        /*
         * Date: October 22, 2002
         * Programmers: Eric and Shawn
         * Description: Update Error Checking
         */
    
         /*
          * Date: October 5, 2002
          * Programmers: Brian
          * Description: Created method
          */
    
    private void removeMonster(UniqueId monster_id){
        Monster monster = (Monster) findCreature(monster_id);
        creatures.remove(monster);
    }
    
    /**
     * Modifies strength of the creature being attacked and gives a description of the fight between two creatures
     * @param attacker    The id of the attacking creature
     * @param attackie    The id of the creature getting attacked
     * @return   A string describing the result of the attack
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
         /*
          * Date: October 30, 2002
          * Programmers: Brian
          * Description: Fixed a few bugs
          */
    
         /*
          * Date: October 10, 2002
          * Programmers: Brian
          * Description: Created method
          */
    private String attack(UniqueId attacker, UniqueId attackie){
        int random_num;
		UniqueId weapon_used;
        boolean got_attacked;
        Creature attacking = findCreature(attacker);
        Creature attacked = findCreature(attackie);
        String fight_description = "";
        List weapon_ids = attacking.getWeaponsWielded();
        
        if (attacking.getClass().getName() == "Monster") {
            // The mosnter is attacking
            got_attacked = false;
            // Loop through all the weapons the creature is wielding
            for (int index = 0; index <= weapon_ids.size()-1; index++) {
                // Randomly select a number between 0 and 100
                random_num = (int) Math.floor(Math.random() * 100);
                // Determine if the monster will attack with the current weapon
                if (random_num < 50 || (index == weapon_ids.size()-1 && got_attacked == false)) {
                    got_attacked = true;
                    weapon_used = (UniqueId) weapon_ids.get(index);
                    if (attacked.getClass().getName() == "Monster"){
                        /* Monster attacks another mosnter and a description of the
                        fight is generated */
                        fight_description = fight_description + ("The " + attacking.getShortName() + " " +
                        am_object.getWeaponVerb(weapon_used) + " the " + attacked.getShortName() + " with its " +
							am_object.getName(weapon_used) + ".\n");
						

                        if (attacked.modifyStrength(-am_object.getStrength(weapon_used)) == false) {
                            fight_description = fight_description + ("The " + attacking.getShortName() + "  killed the " + attacked.getShortName() + ".\n");
                            killCreature(attackie);
                        }
                    } else {
                        /* Monster attacks player and a description of the
                        fight is generated */
                        fight_description = fight_description + ("The " + attacking.getShortName() + " " +
                        am_object.getWeaponVerb(weapon_used) + " you with its " + am_object.getName(weapon_used) + ".\n");
                        if (attacked.modifyStrength(-am_object.getStrength(weapon_used)) == false) {
                            fight_description = fight_description + ("You were killed by the " + attacking.getShortName() + ".\n");
                        }
                    }
                }
            }
        } else {
            // The player is attacking
            int weapon_strength;
            // Determine if the player is wielding a weapon
            if (weapon_ids.size() == 0) {
                // Player has no weapon, so use fists
                fight_description = ("Your fists pound the " + attacked.getShortName() + ".\n");            
                weapon_strength = 1;
            } else {
                // Player has a weapon, so use it
                weapon_used = (UniqueId) ((LinkedList)weapon_ids).getFirst();
                fight_description = ("Your " + am_object.getName(weapon_used) +  " "
                + am_object.getWeaponVerb(weapon_used) + " the " + attacked.getShortName() + ".\n");
                weapon_strength = am_object.getStrength(weapon_used);                
            }
            // Update the the stength of the monster and generate a description of the fight
            if (attacked.modifyStrength(-weapon_strength) == false) {
                fight_description = fight_description + ("You killed the " + attacked.getShortName() + ".\n");
                killCreature(attackie);
            }
        }
        return fight_description;
    }
    
    /**
     * Removes creature from the list of creatures and puts all artifacts carried in room creature resides
     * @param victim_id    The id of the creature being removed
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
         /*
          * Date: October 10, 2002
          * Programmers: Brian
          * Description: Created method
          */
    private void killCreature(UniqueId victim_id){
        Creature creature = findCreature(victim_id);
        creature.dropAllArtifacts(mp_object);
       
		mp_object.removeMoveableObj(creature.getLocation(),creature.getObject().getType(),creature.getObject());
        removeMonster(victim_id);
    }
    
    /**
     * Finds specified creature in creature list
     * @param creature_id    The id of the creature to be found
     * @return   Creature object of specified creature
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
         /*
          * Date: October 1, 2002
          * Programmers: Brian
          * Description: Created method
          */
    public Creature findCreature(UniqueId creature_id){
        if (initialized == false) {
			System.out.println ("Game not initialized.  GO AWAY!!!");
            return null;
        }
        
        int num_creatures;
        Creature temp;
        
        num_creatures = creatures.size();
        for (int index = 0; index <= num_creatures-1; index++) {
            temp = (Creature) creatures.get(index);

//System.out.println (temp.getObject().getUid());

            if ( temp.getObject().getUid() == creature_id.getUid()) {
                return temp;
            }
        }
        
        // Creature not found
        return null;
    }
    
    
    /**
     * Method used for testing, prints all creatures and their properties on the
     * screen
     * @throws   CFMNotInitializedException If the CFM class has not been initialized.
     * @throws   CFMCreatureDoesNotExistException If the Creature ID does not correspond to an existing Creature.
     */
    
    public void PrintCreatures() throws CFMCreatureDoesNotExistException, CFMNotInitializedException {
        Creature creature;
        String print_weapon="";
		UniqueId temp = new UniqueId();
        for (int index = 0; index <= creatures.size()-1; index++) {
			temp.setUid(index);
			temp.setType('c');
            creature = (Creature) findCreature(temp);
            System.out.println("Creature " + index + ":");
            System.out.println("  Type: " + creature.getClass().getName());
            System.out.println("  Unique ID: " + creature.getObject().getUid());
            System.out.println("  Short Name: " + creature.getShortName());
            System.out.println("  Description: " + creature.getDescription());
            System.out.println("  Strength: " + creature.getStrength());
            if (creature.getClass().getName() == "Monster") {
                System.out.println("  Predilection: " + ((Monster) creature).getPredilection());
                System.out.println("  Motility: " + ((Monster) creature).getMotility());
            }
            if (creature.getClass().getName() == "Player") {
                System.out.println("  Points: " + ((Player) creature).getPoints());
            }
            List weapons = creature.getWeaponsWielded();
            System.out.println("  Weapons Wielded:");
            for (int weapon_index = 0; weapon_index <= weapons.size()-1; weapon_index++) {
                System.out.println("    Weapon ID: " + weapons.get(weapon_index));
            }
            System.out.println("  Artifacts:");
            List artifacts=creature.getArtifacts();
            for (int artifact_index = 0; artifact_index <= artifacts.size()-1; artifact_index++) {
                System.out.println("    Artifact ID: " + artifacts.get(artifact_index));
            }
        }
    }
    
}


/*==============================================================================
=                            Custom Exception Class                            =
==============================================================================*/

class CFMAlreadyInitializedException extends Exception {
    CFMAlreadyInitializedException() {
        super("The CFM class has already been initialized.");
    }
}

class CFMNotInitializedException extends Exception {
    CFMNotInitializedException() {
        super("The CFM class has not been initialized.");
    }
}

class CFMCreatureDoesNotExistException extends Exception {
    CFMCreatureDoesNotExistException() {
        super("There is no creature with the ID specified.");
    }
}
