import java.util.*;

public interface CFM_interface{
    

	// change the given monster's predilection to 100
	public boolean makeMonsterAngry(UniqueId uid);
    
	// provide the given uid and the amount of change, change the strength of the given creature and  
	// return true, if this creature is alive
//	public boolean creatureStrengthener(UniqueId uid, int change);
    
	// provide the given uid and return true if the given creature is alive
	public boolean isCreatureAlive(UniqueId uid);

	// provide a uid of a creature and return a list of weapon it has
//	public List creatureWeaponList(UniqueId uid);

	// provide a room id and determine which monstors will hit player
	// return a description of the fighting scene
//	public String fightRequest(UniqueId room_id);

	// provide a monster uid and calculate the player hit it with current wielded weapon
	// return a description of the fighting scene
	public String monsterAttacker(UniqueId monster_uid);

	// provide room A and room B's uid and return a list which indicate which monster will chase the 
	// player from room A to room B
	public List monsterChase(UniqueId room_A_uid, UniqueId room_B_uid);


	// Extra Methods

	// provide creature's uid and return a location(room uid) of this creature 
	public UniqueId getLocation(UniqueId creature_uid);

	// provide creature�s uid and new_room id, set the given room�s uid into creature�s location 
	public boolean setLocation(UniqueId creature_uid, UniqueId room_uid);

	// provide creature's uid and new artifact uid, to add the new artifact to this creature 
	public void addArtifact(UniqueId creature_uid, UniqueId new_artifact_uid);

	//provide creature's uid and new artifact uid, to remove the new artifact from this creature 
	public void removeArtifact(UniqueId creature_uid, UniqueId new_artifact_uid );

	// provide a creature uid and return a List of artifact uid
	public List getArtifact(UniqueId creature_uid);

	// provide a creature uid and return the description of the monster
//	public String getDescription(UniqueId creature_uid);

	// provide a creature uid and return the short name of the monster
	public String getShortName(UniqueId creature_uid);

	// return the point score by the player
	public int point_score();
    
	// set the point score for the player
	public void setScore(int score);

	// provide a weapon uid, and player will �arm� with target weapon
	public void wield(UniqueId weaponId);
  
	// initialize a new creature list inside the CFM class and return a list of moveable object's uid
	public List initialCreatureList();

    // optional, since according to the specification document, saving should
    // be finished by DM. However, logical it is more reasonable to finish in the 
    // other interface. Cos DM should not have any gameObject, it had better only
    // have uid list. But if we put save under DM, DM will need some addition function
    // to get the objectlist from those interface (room, artifact and creature list)
    // and then save it
    //
    // save the mapping list to a file
	//public void save(String filename);
	//public void restore(String filename);

	// if the save function is not implement, 
	// a "getting creature list" function need to be added
	// in order to let the DM to save and restore the all data
//	public List getCurrentList();
//	public void setCurrentList( List creatureList);
		// we have no knowledge of these objects so we can't save them

	// DM will call this function to pass the AM object
	public void setAM(AM AMObject);

	// DM will call this function to pass the MP object
	public void setMP(MP MPObject);


}
