import java.util.*;

abstract class Creature extends MoveableObject {

    // Strength 0 to 100
    private int strength;
	
    // Predilection 0 to 100
    private int predilection;
	
    // Artifact list
    protected List artifacts = new LinkedList();

    // Weapons being wielded
    protected List weapons_wielded = new LinkedList();
		
    // Constructors
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    Creature (String short_name, String description) {
        // Call the constuctor of the super class and pass up paramaters
        super(description, short_name);
	// Randomly select a number for strength between 1 and 100
	strength = (int) (Math.floor(Math.random() * 99) + 1);
        
        // Randomly select a number for predilection between 0 and 100	
	predilection = (int) Math.floor(Math.random() * 100);
    }

    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    Creature (String short_name, String description, int strength,
                int predilection) {
        // Call the constuctor of the super class and pass up paramaters
        super(description, short_name);
        // Store parameters
	this.strength = strength;
	this.predilection = predilection;
    }
    
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */    
    public boolean isAlive () {
        /* Returns true if the creatures strength is greater than 0, false
        otherwise */
        return (strength > 0);
    }

    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public int getStrength() {
        // Return the creatures strength
        return strength;
    }
    
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public void setStrength (int strength) {
        if (strength >= 0 && strength <= 100) {
            // If strenght was in valid range, set it and return true
            this.strength = strength;
            return;
        } else {
            // Strength was outside valid range, return false
            return;
        }
    }
    
    /*
     *Date: October 22, 2002
     *Programers: Brian
     *Description: Added code to ensure strength remains in the valid range.
     */
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public boolean modifyStrength (int Delta) {
        // Update the strength
        strength += Delta;
        // Ensure strength remains in the valid range
        if (strength > 100) {
            strength = 100;
        }
        if (strength < 0) {
            strength = 0;
        }
        return isAlive();
    }
    
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public int getPredilection () {
        // Return the creatures predilection
        return predilection;
    }
    
     /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */               
    public boolean setPredilection (int predilection) {
        if (predilection >= 0 && predilection <= 100) {
            // If predilection was in valid range, set it and return true
            this.predilection = predilection;
            return true;
        } else {
            // Predilection was outside valid range, return false
            return false;
        }
    }

    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public List getWeaponsWielded () {
        // Return the Vector of weapons wielded
        return weapons_wielded;
    }

    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public List getArtifacts () {
        // Return the Vector of artifacts
        return artifacts;
    }
    
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */      
    public boolean addArtifact (int artifact_id) {
        
		
        // Get the index of the artifact in the artifacts Vector
        int artifact_index = artifacts.indexOf(new UniqueId(artifact_id,'a'));
         
        if (artifact_index == -1) {
            /* The creature does not already have the artifact, so add the
             artifact_id to the list of artifacts carried by the creature and
             return true*/
            artifacts.add(new UniqueId(artifact_id,'a'));
            return true;
        } else {
            /* The creature already has the artifact so don't add anything and
             return false */
            return false;
        }
    }
    
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public boolean removeArtifact (UniqueId artifact_id, MP mp_object)  {
        
        // Get the index of the artifact in the artifacts Vector
        int artifact_index = artifacts.indexOf(artifact_id);
        
        if (artifact_index != -1) {
            /* The creature has the artifact, so remove it from the list of
            artifacts and drop it in the room */
            artifacts.remove(artifact_index);
            /* If it exists in the list of weapons wielded, remove it */
            weapons_wielded.remove(artifact_id);
            // add the artifact to the current room
            if (mp_object.addMoveableObj(this.getLocation(),artifact_id.getType(),artifact_id) != true) {
                // throw exception?
            }
            return true;
	} else {
	// Creature does not have the artifact
	return false;
	}
    }
               
    /*
     * Date: October 22, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public void dropAllArtifacts (MP mp_object) {
        
        int num_artifacts = artifacts.size();
        UniqueId artifact_id;
        
        // Go through all artifacts carried by the creature
        for (int index = 0; index <= num_artifacts-1; index++) {
            // Get the unique ID of the artifact
            artifact_id = (UniqueId) artifacts.get(index);
            // Add the artifact to the current room
            if (mp_object.addMoveableObj(this.getLocation(), artifact_id.getType(),artifact_id) !=
                true) {
                // throw exception?
            }
        }
        // Remove all artifact from the list of artifacts
        artifacts.clear();
        
        // Remove all artifact from the list of weapons wielded
        unwieldAllArtifacts();
    }
	        
    abstract public boolean wieldArtifact (int artifact_id);
    
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public boolean unwieldArtifact (int artifact_id) {
        // Remove the artifact from the list of weapons wielded
        return weapons_wielded.remove(new Integer(artifact_id));
    }
   
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public void unwieldAllArtifacts () {
        // Remove all artifacts from the list of weapons wielded
        weapons_wielded.clear();
    }

}
