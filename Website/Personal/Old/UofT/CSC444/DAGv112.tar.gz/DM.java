import  java.util.*;

public class DM
{

	public static	MP mp= new MP();
	public static	AM am= new AM();
	public static	CFM cfm = new CFM();

	public static UniqueId playerId = null;
	public static PlayerTurn pTurn = null;
	public static MonstersTurn mTurn = null;
	


	// sets up the game and performs the main loop
	public static void main(String args[]) throws Exception
	{
		// print into
		System.out.println("\n=================================================");
		System.out.println("                   Welcome to\n");
            System.out.println("T H E   D R A G O N   A D V E N T U R E   G A M E");
		System.out.println("=================================================\n");

		initGame();
	
		while(true)
		{
			pTurn.takeTurn();
			mTurn.takeTurn();

			//quit if the player is dead
			if (cfm.isCreatureAlive(playerId) == false)
			{
				System.out.println("\nYou Have Been Killed.\nGame Over.");
				System.out.println("Total Score: "+cfm.point_score()+"\n");
				break;
			}
		}
		
	}




	/* ___________________________ helper functions ______________________________________*/

	// initializes the game
	private static void initGame() throws Exception
	{
		List artifactIDs = null;
		List roomIDs = null;
		List creatureIDs = null;
		
		playerId = new UniqueId(0, 'c');
		UniqueId room0 = new UniqueId(0, 'r');

		// set the references in the others CSCI
		am.setMP(mp);
		am.setCFM(cfm);
		mp.setAM(am);
		mp.setCFM(cfm); 
		cfm.setAM(am);
		cfm.setMP(mp);
		
		// create the list of artifacts and creatures in the game
		artifactIDs = am.initMovObjects();
		creatureIDs = cfm.initialCreatureList();	// creates the player as well

		//find the main player and remove it the list of creatures
		ListIterator iter = creatureIDs.listIterator();
		UniqueId nextId = null;
		while (iter.hasNext())
		{
			nextId =  (UniqueId) ((MoveableObject) iter.next()).getObject();
			if (nextId.equals(playerId))
				break;
			nextId = null;
		}

		if (nextId == null)
			throw new Exception("ERROR: Can innitialize the game because the player"
				+ " can't be found in the list of creatures.");		
		playerId = nextId;
		//		iter.remove();

		// place the moveable objects on the map
		roomIDs = mp.initialize(artifactIDs);

		// put the player in room zero 
	    	//cfm.setLocation(playerId, room0);
		
		//initialize the player turn class. Might throw exception which will bubble up past main.
		// the first 2 inputs make the list of moveable objects for the vocabulary

		pTurn = new PlayerTurn(artifactIDs, creatureIDs);
		
		// innitialize the monsters turn class
		mTurn = new MonstersTurn();
		
		//print info on first room
	        pTurn.printFirstDescription();
	}


}
