//package am;

import java.io.Serializable;

/**
 * @author Igor Keizner
 */
public class GameObject implements Serializable
{
	private UniqueId uid;
	private String description;

	public GameObject()
	{
		this.uid = new UniqueId();
		this.description = "";
	}

	public GameObject(UniqueId new_uid, String description)
	{
		this.uid = new_uid;
		this.description = description;
	}

	/**
	 * Returns the description.
	 * @return String
	 */
	public String getDescription() 
	{
		return description;
	}

	/**
	 * Returns the UniqueID uid object.
	 * @return UniqueId
	 */
	public UniqueId getObject() 
	{
		return uid;
	}

	/**
	 * Sets the description.
	 * @param description The description to set
	 */
	public void setDescription(String description) 
	{
		this.description = description;
	}

	/**
	 * Sets the uid.
	 * @param uid The uid to set
	 */
	public void setUid(UniqueId uid) 
	{
		this.uid = uid;
	}
}