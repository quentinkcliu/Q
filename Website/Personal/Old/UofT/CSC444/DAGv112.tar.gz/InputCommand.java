/* DATA ABSTRACTION	- InputCommand

Description: The class aquires and stores the input command.
*/


import java.io.*;
import java.util.*;
import java.security.*;

public class InputCommand
{

	public Vocabulary vocab;
	
	public VocabularyItem verb;
	public VocabularyItem object;
	public VocabularyItem tool;	



	/*_____________________ Primative Constructors _________________________________*/


	/*	Procedural Definition
		Name:		InputCommand
		Parameters:	- vocab - vocabulary by which to parse the command (defines the
						Verb, Object, and Tools that are allowed)
		Requires:	- the command must be of the form
							Verb [Object ['with' Tool]]
						Where the [] indicates options syntax, and with is a key word.
						Valid egs of sample commands include:
							attack 
							attack panther
							cut hair with scissors
							use nail with hammer
						Note: All three parts (Verb, Objects, and Tools) can consist
						of multiple words. 
		Effects:	- it parses the users command (For those who have taken the
						compiler course, csc457, it performs lexical analysis
						and syntax checking.
		Modifies:	- the standard input/output to get the command from the user
					- the private variables
		Raises:		- throws an InvalidCommandException if the conditions in the
						requires clause are not met
					- throws an IOException if the unput can not be obtain from the
						user
	*/
	public InputCommand (Vocabulary vocab) throws InvalidCommandException, IOException
	{
		// get the command (input from the user)
		String command;
		System.out.print("> ");
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));  
		command = stdin.readLine(); /* read the line*/
		
		constructorHelper (vocab, command);
	}
	


	/*	Procedural Definition
		Name:		InputCommand
		Parameters:	- vocab - vocabulary by which to parse the command
					- test_command - the command the test program wants to use inplace
						of the users input
		Requires:	- the command must be of the same form as the previous constructor
					- the input test_command can not be null
					- the same conditions for parsing as the previos constructor
		Effects:	- it prints the input test_command with a special prompt
					- otherwise, same as the previos constructor
		Modifies:	- the standard input output to get the command from the user
					- otherwise, same as the previos constructor
		Raises:		- throws an InvalidCommandException if the conditions in the
						requires clause are not met
					- throws an InvalidParameterException if the input test_command is
						null
	*/
	public InputCommand (Vocabulary vocab, String test_command) throws InvalidCommandException
	{
		// validate inputs
		if (test_command == null)
			throw new InvalidParameterException
				("Illegal call to UserInput; The input test_command cannot be null.");
		
		System.out.print("test> " + test_command + "\n");
		constructorHelper (vocab, test_command);
	}




	/*_____________________ Constructors __________________________________________*/

	//none



	/*_____________________ Mutators ______________________________________________*/

	//none
	
	

	/*_____________________ Observers _____________________________________________*/

	/*
	Hence every input can have a Verb, Object, and Tool.  The functions
	below define the observers for the parsed command. There are three   
	questions that can be asked about each part of the input:
		1.) does it exist (was a value provided for the optional argument)
		2.) what is the string for that part?
		3.) was the value for that part defined by the DM?
	*/
	

	/* VERB FUNCTIONS */ 

	/* 1.) can't ask if a verb exists.  Every command must have a verb.*/


	/* 2.) returns the text of the verb */
	/*	Procedural Definition
		Name:		getVerbString
		Parameters:	
		Effects:	- returns the cleaned text of Verb (by clean I mean the function
						clean in the class Vocabualry was run on it)
		Raises:		
	*/		
	public String getVerbString()
	{	
		return verb.getString();
	}
	
	
	/* 3.) returns true if the verb was defined by the DM */
	/*	Procedural Definition
		Name:		isVerbDefinedByDM
		Parameters:	
		Effects:	- returns true if the verb was defined by the DM 
		Raises:		
	*/	
	public boolean isVerbDefinedByDM ()
	{
		return verb.isDefinedByDM();
	}
	
	
	
	/* OBJECT FUNCTIONS */ 

	/* 1.) returns true if the object was found in the command */
	/*	Procedural Definition
		Name:		objectExists
		Parameters:	
		Effects:	- returns true if the object was found in the command
		Raises:		
	*/	
	public boolean objectExists ()
	{
		if ( object == null)
			return false;
		return true;
	}


	/* 2.) returns the text of the object */
	/*	Procedural Definition
		Name:		getObjectString
		Requires:	- the object to exist (check this by running objectExists)
		Parameters:	
		Effects:	- returns the text of the object
		Raises:		- throws a NullPointerException if the object doesn't exist
	*/	
	public String getObjectString() 
	{
		if ( object == null )
			throw new NullPointerException("The object doesn't exist; don't call this method with out"
				+ " checking if it exists using objectExists()" );
		
		return object.getString();
	}
	
	
	/* 3.) returns true if the object was defined by the DM */
	/*	Procedural Definition
		Name:		isObjectDefinedByDM
		Requires:	- the object to exist (check this by running objectExists)
		Parameters:	
		Effects:	- eturns true if the object was defined by the DM
		Raises:		- throws a NullPointerException if the object doesn't exist
	*/	
	public boolean isObjectDefinedByDM () 
	{
		if ( object == null )
			throw new NullPointerException("The object doesn't exist; don't call this method with out"
				+ " checking if it exists using objectExists()" );
		
		return object.isDefinedByDM();
	}
	


	/* TOOL FUNCTIONS */ 

	/* 1.) returns true if the tool was found in the command */
/*	Procedural Definition
		Name:		toolExists
		Parameters:	
		Effects:	- returns true if the tool was found in the command
		Raises:		
	*/	
	public boolean toolExists ()
	{
		if ( tool == null)
			return false;
		return true;
	}


	/* 2.) returns the text of the tool */
	/*	Procedural Definition
		Name:		getToolString
		Requires:	- the tool to exist (check this by running toolExists)
		Parameters:	
		Effects:	- returns the text of the tool
		Raises:		- throws a NullPointerException if the tool doesn't exist
	*/	
	public String getToolString() 
	{
		if ( tool == null )
			throw new NullPointerException("The tool doesn't exist; don't call this method with out"
				+ " checking if it exists using toolExists()" );
		
		return tool.getString();
	}


	/* 3.) can't ask if a tool is defined by the DM because no tool is 
		defined by the DM */





/* _____________________________  helper functions ________________________________ */

	
	/*	Procedural Definition
		Name:		constructorHelper
		Parameters:	- vocab - vocabulary with which to parse the command
					- command - the command to parse
		Requires:	- the input parameters to be non-null
		Effects:	- performs all of the common functionality of the two constructors
		Modifies:	- sets the private variable vocab
		Raises:		- throws an InvalidCommandException if the conditions in the
						constructors are not met
					- throws an InvalidParameterException if one of the inputs is null
	*/
	private void constructorHelper (Vocabulary vocab, String command) 
		throws InvalidCommandException
	{
		// validate inputs
		if (vocab == null)
			throw new InvalidParameterException
				("Illegal call to UserInput constructor; The input vocab cannot be null.");

		this.vocab = vocab;
	
		parseCommand (command);
	}
	
	
	
	/*	Procedural Definition
		Name:		parseCommand
		Parameters:	- command - the command to parse
		Requires:	- the input parameter to be non-null
		Effects:	- parses the command
					- stores the Verb, Object, and Tool in VocabularyItems
		Modifies:	- the private variables for Verb, Object, and Tool
		Raises:		- throws an InvalidCommandException if the conditions in the
						constructors are not met
					- throws an InvalidParameterException the inputs is null
	*/
	private void parseCommand (String command) throws InvalidCommandException
	{
		//validate input
		if (command == null)
			throw new InvalidParameterException
				("Illegal call to doParsing; The input command cannot be null.");

		// prepare to parse the command 
		StringTokenizer st = new StringTokenizer(command);
		String next_word, next_item;

		// get the verb; there should always be one
		next_item = "";
		verb = null;
		while (st.hasMoreTokens()) 	// if breaks on this condition then verb = null
		{
			next_word = st.nextToken();
			if ( next_word.equals("with") )
				break; 			 	// if breaks on this condition then verb = null
			next_item = next_item.concat(" ");
			next_item = next_item.concat(next_word);
			verb = vocab.findVerb(next_item);
			if ( verb != null )
				break;
		}			
		if ( verb == null )
			throw new InvalidCommandException("Cannot find the verb in your command."
				+ "  Type 'help' for information on how to enter commands.");

		
		// get the object if it exists
		next_item = "";
		next_word = "";
		while (st.hasMoreTokens())
		{
			next_word = st.nextToken();
			if ( next_word.equals("with") )
				break;
			next_item = next_item.concat(" ");
			next_item = next_item.concat(next_word);
		}			
		if ( (! next_word.equals("with")) && next_item.equals("") )  //there were no words left in the command		
			setObject(null);
		else if ( next_word.equals("with") && next_item.equals("") )  
			throw new InvalidCommandException("An object must be provided if the with clause is used."
				+ "  Type 'help' for information on how to enter commands.");	
		else 						// set the object
			setObject(next_item.trim());

		
		// get the tool if it exists; if the word with was used a tool should be provided
		if ( ! next_word.equals("with") )
			setTool(null);
		else 
		{
			next_item = "";
			next_word = "";
			while (st.hasMoreTokens())
			{
				next_word = st.nextToken();
				next_item = next_item.concat(" ");
				next_item = next_item.concat(next_word);
			}
			if ( next_item.equals("") )  //there were no words left in the command		
				throw new InvalidCommandException("A tool must be provided if the with clause is used."
					+ "  Type 'help' for information on how to enter commands.");	
			setTool(next_item.trim());
		}
		
	}
	
	
		
	/*	Procedural Definition
		Name:		setObject
		Parameters:	- candidate - the candadite string to set as the object
		Effects:	- stores the VocabularyItem corresponding to the candidate if the
						object is defined in the vocabulary
					- stores null if the candidate is null
		Modifies:	- the private variable object
		Raises:		- throws an InvalidCommandException if the candidate is not an
						Object
	*/
	private void setObject(String candidate) throws InvalidCommandException
	{
		if (candidate == null)
			object = null;
		else 
		{
			object = vocab.findObject(candidate);
			if (object == null)
				throw new InvalidCommandException("Can't understand the object '"
					+ candidate + "'.");
		}
	}



	/*	Procedural Definition
		Name:		setTool
		Parameters:	- candidate - the candadite string to set as the tool
		Effects:	- stores the VocabularyItem corresponding to the candidate if the
						tool is defined in the vocabulary
					- stores null if the candidate is null
		Modifies:	- the private variable tool
		Raises:		- throws an InvalidCommandException if the candidate is not an
						tool
	*/
	private void setTool(String candidate) throws InvalidCommandException
	{
		if (candidate == null)
			tool = null;
		else 
		{
			tool = vocab.findTool(candidate);
			if (tool == null)
				throw new InvalidCommandException("Can't understand the tool '"
					+ candidate + "'.");
		}
	}
	
	
}




