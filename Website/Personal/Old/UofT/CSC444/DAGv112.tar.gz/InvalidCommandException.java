/* We have categorized all the error that can occur.  Also in this file
	are the exception classes we have created. */ 

/*
Exception/Error Categories
---------------------------

1.) Invalid command:
	-throw InvalidCommandException
	-Thrown when there is a lexical, syntactical, or symanctical error in the
		command to be executed.

2.) Coding Errors:
	-known types: InvalidParameterException, InstantiationError,
		NullPointerException
	-eg calling a function with wrong arguments
	-Want the original exception to cause the program to fail.

3.) Integration Error:
	-When an error occurs during a function call to another CSCI.  
	-We want this the program to fail.  To properly debug this we need to be
		do an auto save after each turn.

4.) Fatal Error:
	-eg IOException
	-There is no reason for this command to fail and there is nothing one can do
		if it does.
*/




/*Our Exception classes
  ---------------------*/

/* Class Description: see number 1 above*/
public class InvalidCommandException extends Exception
{

	/*	Procedural Definition
		Name:		InvalidCommandException
		Parameters:	- s - contains the text describing why the command is
						invalid
		Requires:	- the same defaults as the constructor: Exception(String s)
		Effects:	- create an exception for invalid commands
		Raises:		
	*/
	public InvalidCommandException(String s)
	{
		super(s);
	}
	
}
