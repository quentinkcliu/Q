import java.util.*;
import java.io.*;

public class MP implements MP_interface
  {
     // this is the list of all rooms in the game
     private List mapList = new LinkedList();
     private String[] descriptions = new String[40];
	 private static CFM cfmobject;
	 private static AM amobject;

     public MP ()
       {
          descriptions[1] = "A vast banquet hall with 8 golden chandeliers hanging from above in an octogonal pattern, lighting up the room with dazzling shades of gold.";
          descriptions[2] = "Four couches placed in the shape of a square at the center of the room.A circular table is at the center of the couches. Bookshelves line the opposite walls.Candels adjacent the couches on small desks light the room.";
          descriptions[3] = "A bar with 3 stools and numerous wines behind the counter. Numerous glasses hang from the wall. Many tables along the wall opposite the bar. Two dart boards in the north west secluded corner.";
          descriptions[4] = "A 19th century designed king sized bed with curtains surrounding the whole bed. The bed is in the corner of the room. A 6 foot mirror next to the bed and also a drawer.Opposite side of the room contains a closet and shelves of books and personal items.";
          descriptions[5] = "A wine cellar with half the bottles missing from the rack line one side of the room. Barrels upon barrels are stacked upon each other opposite the wine racks. There is a big cylindrical tub at the far end of the room.";                         
          descriptions[6] = "A long bright hallway with pictures of people and places on the wall. A red rug stretchs from the opposite ends of the room. Many scented candels light the hallway.";
          descriptions[7] = "A wine cellar with a five columns of shelves all filled with wine bottles. Green, red, and black colored bottles fill the slots. This appears to be a very small and dusty room.";
          descriptions[8] = "A room with chains for the hands and legs lay are connected to the wall. Only the light from a small window up high in the wall is lighting the room. Sharp mechanical instruments lay on a cart 5 meters directly infront of the chains.";
          descriptions[9] = "A room with a sharp blade about 10 feet hovering above the ground. A String is attached to this blade for release. A large half circle lay at the bottom center with small half circles on either side. The device is in the center of the room with a basket infront of the large half circle.";
          descriptions[10] = "A plain room with only a guest bed in the center. Plain white sheet lines the bed. No other accessories except a light on a small cabinet beside the bed.";
          descriptions[11] = "This is a food storge room. Mainly canned foods such as corn, beans, and soup lay on 3 rows of shelves. Bread is placed on the top of the shelves. There are some kitchen utensils on the bottom of the shelves.";
          descriptions[12] = "Storage room of miscallenous items. Large equipment such as a broken refrigerator to smaller items like old newspapers and clothes.A few large swords, protective armor, and helmets are placed together on its own shelf.";
          descriptions[13] = "Unrenovated room, walls not painted, floor not completed. The room reeks of odour. Holes and cracks line the rotton wooden wall.";
          descriptions[14] = "Very large and clean bathroom. The sink is next to toilet under a mirror that is part of a cabinet. Laundry basket contains a few personal items and rugs line the floor.";
          descriptions[15] = "A meeting room. Many chairs surround a long oval desk. There is seating capacity for 20 people with a unique larger chair at the end of the table.";
          descriptions[16] = "Small office with just a few books on the desk. Cabinets are on either side of the desk. A wooden rocking chair accompanies the desk.";
          descriptions[17] = "Small washroom with just a toliet and cracked mirror. It appears to not have been cleaned for an extended period of time.";
          descriptions[18] = "Utility shed for outdoor work. Lawn mower, extension cable, gas, hammer, screw driver, paint, wooden boards, and other outdoor equipment lie scattered in the shed.";
          descriptions[19] = "A library of a wide collection of books; fiction, non-fiction, science fiction, and childrens books appear on all sides of the room. A rocking chair with foot rest is located at the center of the room.";
          descriptions[20] = "A few bucket with water of different sizes are on the floor. A few wet clothes are also on the floor. A fishing line attached to opposite ends of the wall has been used to hold up clothes to be dried.";
          descriptions[21] = "Bedroom with two beds. Bed on the left is made with pillows fluffed and blanket tidily wrapping the bed. Bed on the right has not been made and pillow is on the floor.";
          descriptions[22] = "Dim hallway with a squeeky wooden floor. Chandelier lights the hallway. Small cabinets on either side of the room near the entrance.";
          descriptions[23] = "A kitchen with an oven next to a dual sink. Opposite the sink is a refridgerator. Many cabinets are above the vents that are over the stove.A few plants hang at the corners of the room";
          descriptions[24] = "A dining area where a big table lay in the center of the room. Chairs surrond the table, with placemats and eating utensils at designated sitting spots a checkered mat covers the table.Salt and pepper shakkers on the end of the table";
          descriptions[25] = "Weight traning room with dumbells and bags of sand. Multiple punching bags of various sizes through out the room. An outer running track seems to follow the outside lining of the room.";
          descriptions[26] = "A room with bars in a square shape forming a prison. There are three that stand side by side. Chains lie at the side with a small cup for water in each cell.A cabinet next to the entrance is chained.";
          descriptions[27] = "A cell with hay lining the floor encompasing the entire room. The room is otherwise empty with minimal light coming from the cracks in the wall.";
          descriptions[28] = "A room where books lay scattered all over the floor. The walls are damaged. Light fixtures are broken. Shelves have been destroyed, with nothing left standing.";
          descriptions[29] = "A room with a chair infront of a fire place. Pictures of people hang over the entire fire place. Stuffed animals lay on the walls adjacent the fire place.";
          descriptions[30] = "Two broken lamps lay on the floor. A broken vase lay at the center of the table at the far end of the room. Childrens toys scatter the floor.";
          descriptions[31] = "A collections room with glasses, trophys, and valuable objects. The collection lay behind a glass cover.  Larger items such at a pool table has the balls set up.";
          descriptions[32] = "A bathtub with the water left running is in the corner of the room. There is a lot of water on the floor. A window is open and you can see the green pastures of outside.";
          descriptions[33] = "A room filled with toys and stuffed animals made from sheep skin. A small chair for an infant lay broken in two. A crib lay inbetween the two windows of the room.";
          descriptions[34] = "A furnance and water heater. Many pipes are interconnected. Hot water drips from the largest pipe near the ceiling.Steam is blowing constantly from a red pipe.";
          descriptions[35] = "A ladder is placed next to the entrance. Buckets scatter the floor, some filled with a redish water, while others empty. the buckets are cathing the water that is dripping from the ceiling.";
          descriptions[36] = "Many different variety of plants are haning from the ceiling and placed on the floor.  Long benches are placed near the wall. A green water hose is neatly wound on the wall hose holder.";
          descriptions[37] = "A washroom where the toliet has sprung a leak. There is a bathtub and slim yet 6foot tall mirror. A few handle bars are placed within the bathtub area.";
          descriptions[38] = "A study area.  Shelves of books lay on one end of the room. The other end of the room is filled with chairs arranged in an 5 x 5 array.A chalk board is on a wall facing the chairs.";         
	  descriptions[39] = "Dining tables with chairs are placed such that they fill the entire room. Candles on each table light the room. There are forks, spoons, and plates evenly distributed on each table.";
          descriptions[0] = "Four desks are placed at the corners of the room. The center of the room contains an circular desk with a center piece. Pictures are placed in between the desks.";
          this.initializer();
       }

     public void setAM (AM am_object ) {

	amobject = am_object;
     }

     public void setCFM (CFM cfm_object ) {

	cfmobject = cfm_object;
     }

     // randomly places a list of object ids into random rooms. Returns the list of rooms.
     public List initialize(List moveable_obj_list)
       {
         int totalobjects = moveable_obj_list.size();
         int totalrooms = mapList.size();
         Random seed = new Random();
         UniqueId nextobject, randroom;
         //List returnlist = new LinkedList();

         int objectscount = 0;
	 int randnum = 0;
         randroom = new UniqueId();
         randroom.setType('r');     // the type is a room
         while (objectscount < totalobjects)
           { 	
	        
             // get the next object from the list
             nextobject = ((MoveableObject)moveable_obj_list.get(objectscount)).getObject();
         
             // get a random room number
	     randnum = seed.nextInt()%totalrooms;
	     if (randnum < 0)
	        randnum = randnum*(-1);

        // create a new room UniquId object, and put moveable object in it
        randroom = new UniqueId( (((room)(mapList.get(randnum))).getUid()).getUid(),'r');
        addMoveableObj(randroom, nextobject.getType(), nextobject);
		
		// This is for a creature list
		if (nextobject.getType() != 'a')
		  {
	     // create a new UniqueId with the random room id in it. Then add it to the
	     //  moveable object lists of the room.
			 ((Creature)(cfmobject.creatures.get(objectscount))).setLocation(randroom);
              
 /*            // add the roomid to the liked list to be returned
             returnlist.add(randroom);*/
		  }
		else
		  {

		     Artifact tempart;
			 UniqueId tempartid;
			 
			 tempart = (Artifact)(amobject.list.get(objectscount));
			 tempartid = tempart.getObject();
			 
			 amobject.setLocation(tempartid,randroom);
		    
		  }
            
             objectscount++;
           }

         return mapList;         
       }

     // This function reads the map network from a file called "rooms.cfg"
     // returns "true" if successful
     public boolean initializer()
       {
         DataInputStream dis = null;
	 StringTokenizer reader, portalreader, dirreader, sucreader;
	 String portaltxt;
	 Random randnum = new Random();
	 
	 String record = null;
	 UniqueId sucid;
	 
	 int numrooms;
	 int numportals;
	 int suc;
	 int dir;
	 int rmid;
	 int randomint;
	 
	 //String numrooms;
	 //String numportals;
	 //String dir;
	 //String suc;
	 
	 int recCount = 0;
	 int roomcount = 0;
	 int portalcount = 0;
	 
	 try
	   {
	     File f = new File("rooms.cfg");
	     FileInputStream fis = new FileInputStream(f);
	     BufferedInputStream bis = new BufferedInputStream(fis);
	     dis = new DataInputStream(bis);

	     reader = new StringTokenizer(record=dis.readLine());
	     if (record  == null)
	       {
	         return false;
	       }
	       
// read the total number of rooms in	     
             numrooms = Integer.parseInt(reader.nextToken());
	     
	     room newroom;
	     Portal newportal;

             while (numrooms > roomcount)
	       {
            // create a room and put it in the rooms linkedlist
		 mapList.add(newroom = new room());
		
// read in the room id# 
	       reader = new StringTokenizer(record=dis.readLine());
   		 if (record == null)    return false;

		 rmid = Integer.parseInt(reader.nextToken());
             newroom.uid = new UniqueId();
		 newroom.uid.setUid(rmid);

// read in the number of portals for this room
	         reader = new StringTokenizer(record=dis.readLine());
		 if (record == null)
		   {
		     return false;
		   }
		 
		 numportals = Integer.parseInt(reader.nextToken());
		 portalcount = 0;
		 while (numportals > portalcount)
		   {
// read the direction of the portal
		     reader = new StringTokenizer(record=dis.readLine());
		     if (record == null)
		       {
		         return false;
		       }
		     dir = Integer.parseInt(reader.nextToken());
		     
// read the successor id of the portal
		     reader = new StringTokenizer(record=dis.readLine());
		     if (record == null)
		       {
		         return false;
		       }
		     suc = Integer.parseInt(reader.nextToken());

// read the description of the portal
		     portaltxt = new String(record=dis.readLine());
		     if (record == null)
		       {
		         return false;
		       }
		     
		     // direction can only be 0-north,1-east,2-south,3-west
		     if (dir < 0 || dir > 3)
		       {
		         System.out.println ("Invalid cfg file direction. Aborting...\n");
			 return false;
                       }
		     
		     if (suc < 0)
		       {
		         System.out.println("Invalid successor id (must be positive)\n");
			 return false;
		       }
		     
                     // add all of the read values into their  respective objects
		     //newportal = new portal();
		     sucid = new UniqueId();
		     sucid.setUid(suc);
		     //newportal.initportal(portaltxt, dir, sucid);
		     ((Portal)(newroom.portalList.get(dir))).initportal(portaltxt,dir,sucid);
		     randomint = randnum.nextInt();
		     if (randomint < 0)
		       randomint = randomint*(-1);
		       
		     newroom.description = descriptions[ randomint % 40 ];
		     portalcount++;
		   }
		 
	         roomcount++;
	       }

	   }
	 catch (IOException e)
	   {
	     //catch any file errors
	     System.out.println("IO Exception error. Trouble with rooms.cfg. Aborting...\n");
             return false;
	   }
	 finally
	   {
	     if (dis != null)
	       try
	         {
		   dis.close();
		 }
	       catch (IOException ioe) {return false;}
	   }
	 
	 return true;
       }

     // takes the roomid and returns a list of creature ids of the creatures in that room
     public List getCreatureList(UniqueId room_id)
       { 
         room foundroom;  // where to store the resulting room from the search
	 
	 // find the specified room          
         foundroom = (room)FindRoom(room_id);
 
         // check to see if room exists, otherwise return null
         if (foundroom == null)
           {
             return null;
           }  
        
	 // return the creature list from the room
         return (List)(foundroom.creatureList);
       }

     // takes the objectid, object type (creature='c'/artifact='a'), and roomid to put object in
     // returns true if successful, false otherwise
     public boolean addMoveableObj( UniqueId roomid, char classtype,  UniqueId objectid)
       {
         room roomfound;  // where to store the resulting room from the search
 
         // find the specified room
	 roomfound = (room)FindRoom(roomid);
 
         // check to see if room exists, otherwise return false
         if (roomfound == null)
           {
             return false;
           }  

         // determine which class type to work with
         if (classtype == 'c' || classtype == 'C')
           {
             // see if the object is in the room already
             List creaturesinroom;

             // put the creature list in an easy to understand variable name
             creaturesinroom = roomfound.creatureList;

             // this is just an extra check to ensure nothing is wrong with the list
             if (creaturesinroom == null)
                {
                  return false;
                }

             //go through the list of creatures and check their ids
             for (int i=0;i<creaturesinroom.size();i++)
               {
                 if ( ((UniqueId)creaturesinroom.get(i)).getUid() == objectid.getUid())
                   {
                     return false;
                   }
               }                      

             //insert the creature into the room, update all object info
             creaturesinroom.add(objectid);
           }
         else if (classtype == 'a' || classtype == 'A')
           {
             // see if the object is in the room already
             List artifactsinroom;
             
             // put the artifact list in an easy to understand variable name
             artifactsinroom = roomfound.artifactList;

             // this is just an extra check to ensure nothing is wrong with the list
             if (artifactsinroom == null)
               {
                 return false;
               }

             //go through the list of creatures and check their ids
             for (int i=0;i<artifactsinroom.size();i++)
               {
                 if ( ((UniqueId)artifactsinroom.get(i)).getUid() == objectid.getUid())
                   {
                     return false;
                   }
               }  
	       
             //insert the artifact into the room, update objects
             artifactsinroom.add(objectid);
           }
         else
           {
             return false;
           }

         return true;
       }

    /*Assuming that the room list is global linked list to the program, and that 
      the room identifier is an integer and the portal list is set up as an array 
      of 4 where the integers 0,1,2,3 represent the directions N,E,S,W 
      respectively where the contents of that cell will hold the id of the room 
      adjacent to that door. Returns Room ID on successful search. or null.*/

    public UniqueId getSuccessor(UniqueId searchForRoom, char dirn)
      {

        room roomfound = null;    // where to store the found rooms        
        int direction;            // the converted direction index (from the character version)
        
	// convert the direction character into an index (as stated in method description above).
	if (dirn == 'n' || dirn == 'N')
	  {
	    direction = 0;
	  }
	else if (dirn == 'e' || dirn == 'E')
	  {
	    direction = 1;
	  }
	else if (dirn == 's' || dirn == 'S')
	  {
	    direction = 2;
	  }
	else if (dirn == 'w' || dirn == 'W')
	  {
	    direction = 3;
	  }
        else
	  {
	    return null;  // invalid direction
	  }
	
	// search for the room from the list of rooms  
        roomfound = (room)FindRoom(searchForRoom);

        // check if the room exists. 
        if (roomfound == null)
          {
            return null;  // invalid roomid entered
          }

        // check if the portal exists
        if ( ((Portal)(roomfound.portalList.get(direction))).getUid().getUid() < 0)
          {
            return null;
          }

        // return successorid
        return ((Portal)(roomfound.portalList.get(direction))).successorid;
         
      }

    /*Assuming that the artifact list is kept as a linked list within the room
      object returns Artifact list if there is a list to be found in the room
      and NULL otherwise.					*/
    public List getArtifactList(UniqueId searchForRoom)
      {
        room roomfound;

        // find the specified room
	roomfound = (room)FindRoom(searchForRoom);
	        
        // if the room wasn't found, return a null list
        if (roomfound == null)
          {
            return null;
          }
        else
          {
            return (List)(roomfound.artifactList);
          }
      }
       
    /* a function which returns a room object, given the room's unique id. Returns null if room doesn't exist*/
    private room FindRoom (UniqueId room_id) 
      {
	int size =  mapList.size();
	/*returns the number of elements in the mapList list. */

	room traverse;
	
	// Go through the list of rooms, and compare their ids to find the correct one. Otherwise, return null.
	for (int i=0; i<size; i++) 
	  {
	    traverse = (room)(mapList.get(i));
	    if (traverse.uid.equals(room_id) ) 
	      return traverse;
	  }
	
	return null;
      }

    // This function simply returns the portal-list 
    public List getPortalList (UniqueId room_id) 
      {
	/*search all the rooms in the global portal_list for the direction and 
	description of the desired room. */

	room temp;
	temp= FindRoom (room_id);

	if (temp!= null)
	  return (List)(temp.portalList);		
	else
	  return null;

      }


    /* searches the room_list for the room in which the object resides to be deleted, 
    either creature or artifact according to its class_type, then searches that 
    appropriate list (Creature or Artifact) given its obj_id, and removes the 
    item by the use of a helper function, FindAndRemove. Returns true if item 
    was deleted.*/

    public boolean removeMoveableObj (UniqueId room_id, char type, UniqueId obj_id) 
      {

	boolean result;
	room roomfound;                       // stores the room w/ the specified room_id that was found
	
	roomfound = (room)FindRoom (room_id); // find the specified room from its room_id

        // check to see that the room exists, otherwise return false
	if (roomfound == null)	  
	  return false;

	/*search either the creature list or the artifact list for the obj_id*/
	if (type == 'c' || type == 'C') 
	  {
	    result= FindElementAndRemove ((List)(roomfound.creatureList), obj_id);
            return result;
	  }
	else if (type == 'a' || type == 'A')
	  {
	    result =FindElementAndRemove ((List)(roomfound.artifactList), obj_id);
	    return result;
	  }
        else
          {
            return false;
          }	  
      }

    /*finds the correct element to delete, and performs the removal from the appropriate list. */
    private boolean FindElementAndRemove (List givenlist, UniqueId object_id) 
      {
	/*thing list is either the artifact or creature list, which stores only integer id values. */
	int size = givenlist.size();
	UniqueId found_object_id; 
	
	// look through the list of elements to find the object id and remove it.
	for (int i=0; i<size; i++) 
	  {
	        // get the Integer object from the list, and compare it to the specified objectid
		found_object_id = (UniqueId)(givenlist.get(i));
		if (found_object_id.getUid() == object_id.getUid() ) 
		  { 
		    givenlist.remove(found_object_id);
		    return true;
		  }	
	  }

	return false;

      }
	
   // returns -1 if the room was not found, return 1 if the operation was successful.
   public void appendDescription(UniqueId unique_ID, String piece_of_text) 
     {
       // search for the specified room
       room current_room = FindRoom(unique_ID);
   
       // check to see if the room exists. Return -1 otherwise.
       if (current_room == null)
         return;

      
       if (piece_of_text == "") 
         {
            return; /* nothing to add*/
         } 
       else 
         {
           current_room.description += piece_of_text; /* append description */
           return;
         }

     } /* method room_decor */

   // returns null if the room was not found, or 
   public String getDescription(UniqueId unique_ID) 
     {

        room current_room = FindRoom(unique_ID);

        if (current_room == null) 
	  {
            return null;
          }

        return current_room.description;
	    
   } /* method room_describe */

   public List getCurrentList()
     {
       return (List)mapList;
     }

   public void setCurrentList(List roomList)
     {
       mapList = roomList;
     }

}



class room implements Serializable
  {
    public UniqueId uid;              //unique id;
    public String description;  //description of the room

    /* list of portals in the room (index = direction) ie. 0-north,1-east,2-south,3-west */
    public List portalList = new LinkedList();      // the portal list (four portals at most).
    public List creatureList = new LinkedList();    // list of creatures
    public List artifactList = new LinkedList();    // artifact list    

   public room()
     {
       uid = null;
       description = null;              

       portalList.add(0,new Portal());
       portalList.add(1,new Portal());
       portalList.add(2,new Portal());
       portalList.add(3,new Portal());
     }

   public room(UniqueId new_uid, String description)
     {
       uid = new_uid;
       this.description=description;

       portalList.add(0,new Portal());
       portalList.add(1,new Portal());
       portalList.add(2,new Portal());
       portalList.add(3,new Portal());

     }

   public UniqueId getUid()
     {
       return this.uid;
     }

   public String getDescription()
     {
       return description;
     }

   public void setDescription(String desc)
     {
       this.description = desc;
     }

  }



