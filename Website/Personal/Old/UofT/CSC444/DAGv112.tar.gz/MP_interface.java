import java.util.*;

public interface MP_interface{
   

	// provide the room's uid and direction, return adjacent room's uid  
	// The direction should be a character ( N(North), E(East), S(South), W(West) )
	public UniqueId getSuccessor(UniqueId uid, char direction);
   
	// provide the moveable object uids list return a list of rooms uids
	public List initialize(List moveable_obj_list);

	// provide the uid and return the description of that uid
	public String getDescription(UniqueId room_id);

	// provide uid and new description and it will attach to the current description
//	public void appendDescription (UniqueId room_id, String new_description);
   
	// provide uid and return the list portal object from that room
	public List getPortalList(UniqueId room_id);

	// provide uid and return the list of artifact uid from that room
	public List getArtifactList(UniqueId room_id);

	// provide uid and return the list of creature uid from that room
	public List getCreatureList(UniqueId room_id);

	// provide the room's uid, moveable object's uid and its type, 
	// to add the target moveable object id to the list in the given room
	// return true if the moveable object is added 
	public boolean addMoveableObj(UniqueId room_id, char type, UniqueId moveable_id);
   
	// provide the room's uid, moveable object's uid and its type, 
	// to remove the target moveable object id from the list in the given room
	// return true if the movable object is removed
	public boolean removeMoveableObj(UniqueId room_id, char type, UniqueId moveable_id);

	// optional, since according to the specification document, saving should
	// be finished by DM. However, logical it is more reasonable to finish in the 
	// other interface. Cos DM should not have any gameObject, it had better only
	// have uid list. But if we put save under DM, DM will need some addition function
	// to get the objectlist from those interface (room, artifact and creature list)
	// and then save it
	//
	// save the mapping list to a file
//	public void save(String filename);
//	public void restore(String filename);
   
	// if the save function is not implement, 
	// a "getting Room list" function need to be added
	// in order to let the DM to save the all data
//	public List getCurrentList();
//	public void setCurrentList(List roomList);
		// we have no knowledge of these objects so we can't save them

	// DM will call this function to pass the AM object
	public void setAM(AM am_object);

	// DM will call this function to pass the CFM object
	public void setCFM(CFM cfm_object);
    
}
