class Monster extends Creature {
    
    // Motility 0 to 100
    private int motility;
    
    Monster (String short_name, String description) {
        // Call the constuctor of the super class and pass up paramaters
        super(description, short_name);
        // Randomly select a number for motility between 0 and 100	
        motility = (int) Math.floor(Math.random() * 100);
        // May have to change order of parameters when integrating
    }
	
    Monster (String short_name, String description, int motility) {
        // Call the constuctor of the super class and pass up paramaters
        super(description, short_name);
        this.motility = motility;
    }
	
    Monster (String short_name, String description, int strength,
                int predilection) {
        // Call the constuctor of the super class and pass up paramaters
        super(description, short_name, strength, predilection);
        // Randomly select a number for motility between 0 and 100	
        motility = (int) Math.floor(Math.random() * 100);
    }
	
    Monster (String short_name, String description, int strength,
                int predilection, int motility) {
        // Call the constuctor of the super class and pass up paramaters
        super(description, short_name, strength, predilection);
        // Stores the parameter
        this.motility = motility;
    }	
    
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public int getMotility () {
        // Returns the monsters motility
        return motility;
    }
        
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public boolean setMotility (int motility) {
        if (motility >= 0 && motility <= 100) {
            this.motility = motility;
            return true;
        } else {
            // Error
            return false;
        }            
    }
    
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public void makeAngry () {
        // Check if Monster is alive
        if (isAlive()) {
            setPredilection(100);
        }
    }
    
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public boolean wieldArtifact (int artifact_id) {
        // Check if the creature has the artifact
	if (artifacts.indexOf(new Integer(artifact_id)) != -1) {
            /* Creature has the artifact, so add the artifact to the list of
            weapons wielded, and return true */
            weapons_wielded.add(new Integer(artifact_id));
            return true;
        } else {
            // Creature does not have the artifact, return false
            return false;
	}
    }
	
}
