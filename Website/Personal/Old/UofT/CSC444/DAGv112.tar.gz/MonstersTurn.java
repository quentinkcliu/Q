import java.util.*;

public class MonstersTurn
{
	
	// gives all appropriate monsters the chance to attack or chase
	// 	- only monsters in the same room as the player have a chance to attack
	//  - monsters can only chase if the player has just moved to a new room and
	//		they were attacked in the previous room
	public void takeTurn()
	{
		UniqueId roomPlayerIn = null;

		System.out.println("in Monsters takeTurn");

		// find the room the player is in
		roomPlayerIn = DM.cfm.getLocation(DM.playerId);

		// give the monsters a chance to attack the player (must be in the same room)
//		System.out.println (DM.cfm.fightRequest(roomPlayerIn));
			// I am assuming the description of the fight indicates which
			//	monster is attacking.
		
		// let monsters chase
		makeMonstersChase();

	}
	


	// makes monsters chase the player's if the player has just moved
	private void makeMonstersChase()
	{
		UniqueId previousRoom = null;
		UniqueId currentRoom = null;
		List monstersChasing = null;

		// check the player is still alive (return if the player is dead)
		if (DM.cfm.isCreatureAlive(DM.playerId) == false)
			return;
		
		// check if the player has just moved
		if ( DM.pTurn.didPlayerMove() == false )
			return;

		// get the current and previous room the player was in 
		currentRoom = DM.cfm.getLocation(DM.playerId);
		previousRoom = DM.pTurn.getPreviousRoom();

		// determine which monsters will chase the player
		monstersChasing = DM.cfm.monsterChase(previousRoom, currentRoom);

		// remove those monsters from the old room and add them to the currect room
		ListIterator iter = monstersChasing.listIterator();
		UniqueId nextMonsterID = null;
		while (iter.hasNext())
		{
			nextMonsterID = (UniqueId) iter.next();
			
			// print a message the the monster is chasing
			System.out.println( DM.cfm.getShortName(nextMonsterID)
				+ " chases " 
				+ DM.cfm.getShortName(DM.playerId)
				+ " into this room." );

			// move the monster to the room the player is currently in
			DM.cfm.setLocation(nextMonsterID, currentRoom);
				// I am assuming this calls the AM functions to add and remove objects
			
		}

	}


}
