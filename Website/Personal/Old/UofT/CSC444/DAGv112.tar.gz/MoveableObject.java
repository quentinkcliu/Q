//package am;

/**
 * @author Igor Keizner
 */
public class MoveableObject extends GameObject 
{
	private String shortName;
	private UniqueId location;
	private int strength;

	/**
	 * @see java.lang.Object#Object()
	 */
	public MoveableObject() 
	{
		super();

		this.shortName = "";
		this.location = new UniqueId();
		this.strength = 0;
	}

	public MoveableObject(String short_name, String description)
	{
		super();
		this.shortName = short_name;
		this.setDescription(description);
	}
	
	/**
	 * Method MoveableObject.
	 * @param new_uid
	 * @param description
	 * @param shortName
	 * @param location
	 * @param strength
	 */
	
	public MoveableObject(UniqueId new_uid,
           		           String description,
		                   String shortName,
		                   UniqueId location,
		                   int strength) 
	{
			
		super(new_uid, description);
		this.shortName = shortName;
		this.location = location;
		this.strength = strength;
	}

	/**
	 * Returns the location.
	 * @return UniqueId
	 */
	public UniqueId getLocation() 
	{
		return location;
	}

	/**
	 * Returns the shortName.
	 * @return String
	 */
	public String getShortName() 
	{
		return shortName;
	}

	/**
	 * Returns the strength.
	 * @return int
	 */
	public int getStrength() 
	{
		return strength;
	}

	/**
	 * Sets the location.
	 * @param location The location to set
	 */
	public void setLocation(UniqueId location) 
	{
		this.location = location;
	}

	/**
	 * Sets the shortName.
	 * @param shortName The shortName to set
	 */
	public void setShortName(String shortName) 
	{
		this.shortName = shortName;
	}

	/**
	 * Sets the strength.
	 * @param strength The strength to set
	 */
	public void setStrength(int strength) 
	{
		this.strength = strength;
	}
}