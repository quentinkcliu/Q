class Player extends Creature {
    // Points
    private int points;
	
    // Unique ID of player is 0

    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */ 
    Player (String short_name, String description) {
        // Call the constuctor of the super class and pass up paramaters
        super(short_name, description,100, 0);
        points = 0;
    }
	
    /*
     * Date: October 22, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public int modifyPoints (int delta) {
        // Update points
        points += delta;
        // Ensure points remain positive
        if (points < 0)  points = 0;
        return points;
    }
    
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public int getPoints () {
        return points;
    }

    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public void setPoints(int points) {
        // Set the points
        this.points = points;
        // Ensure the points remain positive
        if (this.points < 0) this.points = 0;
    }
        
    /*
     * Date: October 1, 2002
     * Programmers: Brian
     * Description: Created method
     */
    public boolean wieldArtifact (int artifact_id) {
        // Check if the creature has the artifact
	if (artifacts.indexOf(new Integer(artifact_id)) != -1) {
            /* Creature has the artifact, so add the artifact to the list of
            weapons wielded, and return true */
            unwieldAllArtifacts();
            weapons_wielded.add(new Integer(artifact_id));
            return true;
        } else {
            // Creature does not have the artifact, return false
            return false;
	}
    }
        
}
