import java.io.*;
import  java.util.*;

public class PlayerTurn{

    private Vocabulary vocab;

	private boolean playerJustMoved = false;
	private UniqueId previousRoom = null;
//    private MP mp = new MP();	
	
	
	//______________________________________ Public Methods ___________________________

    // constructor 
	// initializes the vocabulary
    public PlayerTurn(List artifactIds, List creatureIds) throws Exception {
        String[] DMVerbs = {"move", "go", "walk","look", "inspect",
		                    "take","drop", "list", "lose", "pick up", "health",
                             "fight", "wield"/*,"hit"*/,"attack",
                            "save", "restore", "score", "help", "exit", "quit"};
        String[] DMObjects = {"north", "n", 
                              "south", "s", 
                              "west",  "w", 
                              "east",  "e", 
                              "it"};
        
        String[] moveableObjects = new String[artifactIds.size() + creatureIds.size()];
        int i = 0;

        ListIterator iter = artifactIds.listIterator();
        while (iter.hasNext()) {
            moveableObjects[i++] = DM.am.getName(((Artifact)iter.next()).getObject());
        }
        iter = creatureIds.listIterator();
	
	    
        while (iter.hasNext()) {
            moveableObjects[i++] = DM.cfm.getShortName((UniqueId) ((MoveableObject) iter.next()).getObject());
        }	

        List actionsList = DM.am.listAllArtifactsActions();
        String[] actions = new String[actionsList.size()];
        i = 0;
        
        iter = actionsList.listIterator();
        while (iter.hasNext()) {
            actions[i++] = (String) iter.next();
        }
        
        vocab = new Vocabulary(DMVerbs, DMObjects, actions, moveableObjects);
    }
    
  
	// performs one turn for the player (by calling various helper functions 
	//	to process each type of command)
	public void takeTurn () {		
		 playerJustMoved = false;
	
	    while (true){ /*loop until no InvalidCommand exception is thrown */
        	try {
			    InputCommand command = new InputCommand(vocab);
                String word = command.getVerbString();	
                
                /* the command is one of the predefined action verbs */
		        if (command.isVerbDefinedByDM()){
		      	
				    if (word.equals("move") || word.equals("go") || word.equals("walk")) {
				        processMovement(command);
                        break; // if no InvalidCommand exceptions were thrown, program will break out of the while loop
                    }

					else if (word.equals("attack") || word.equals("fight") || word.equals("hit")) {
	    		        processAttack(command);
                        break; // if no InvalidCommand exceptions were thrown, program will break out of the while loop
                    }

					else if (word.equals("look") || word.equals("inspect"))
			  			processInformation(command);
							
					else if (word.equals("take") || word.equals("pick up"))
			  			processTake(command);
												
					else if (word.equals("drop") || word.equals("lose"))
			  			processDrop(command);
						
					else if (word.equals("list"))
						processList(command);
                    	
					else if (word.equals("wield"))
						processWeild(command);

					else if (word.equals("save"))
						processSave(command);

					else if (word.equals("restore"))
						processRestore(command);

					else if (word.equals("score"))
						processScore(command);

					else if (word.equals("help"))
						processHelp(command);

					else if (word.equals("health"))
						processHealth(command);

					else if ( word.equals("exit") || word.equals("quit") )
						processExit(command);
					    
					else
                        throw new InvalidCommandException("The verb written is not defined by the DM.");
                        
				//else its not one of the DMaction verbs
				//so find out what the object is and then call the AM's action module
	  			} else {
					processNonDMAction(command);
                }
                
			} catch (InvalidCommandException e) {
                System.out.println(e.getMessage());
            } catch (IOException e) {
                System.out.println("IOException caught! Try again.");
            }
		} 
    }



	// Prints the description when a room is first entered including a desc of the rooom
	//	itself, desc of it's portals, a list of artifacts and creatures in the room
    public void printFirstDescription() {
        printRoom();
    }



	// Returns true if the players last command was a move command
	public boolean didPlayerMove()
	{
		return playerJustMoved;
	}


	
	// Returns the UniqueId of the room the player was previously in, returns
	// 	null if the player hasn't moved
	public UniqueId getPreviousRoom()
	{
		return previousRoom;
	}




	// _______________________ Functions To Process Each Type Of Command ___________________________

    // from the command object, determines whether a move in a direction (stored in object) 
    // can be performed. A valid direction must be given and a portal in that direction must exist
    // and must be unlocked. If successful, the player is moved into the room and a full description
    // of the room, portal, artifacts and creatures present is displayed.
    private void processMovement(InputCommand command) throws InvalidCommandException {
      	String direction;
        char dirChar;
        UniqueId currRoom, nextRoom;
       
		if (!command.objectExists()) //if object doesn't exist throw exception
            throw new InvalidCommandException("No direction in the movement command present.");
            
      	if (!command.isObjectDefinedByDM()) //if object is not defined by DM throw exception
            throw new InvalidCommandException("Direction in the movement command is invalid.");
            
		direction = command.getObjectString();		//otherwise get direction
      	
      	// parse direction
	    if 	(direction.equals("north")|| direction.equals("n")) {
            dirChar = 'n';
     	} else if (direction.equals("south")|| direction.equals("s"))
            dirChar = 's';
       	else if (direction.equals("west") || direction.equals("w"))
            dirChar = 'w';
		else if (direction.equals("east") || direction.equals("e"))
            dirChar = 'e';
		else
            throw new InvalidCommandException("The object in the movement command is not a direction.");
            
        // assume class Portal is as defined in Javadoc (http://www.tripledoubleyou.com/mapping/doc/index.html)
        currRoom = DM.cfm.getLocation(DM.playerId);
        List portalList = DM.mp.getPortalList(currRoom);
        ListIterator iter = portalList.listIterator();
        
        while(iter.hasNext()) {
            Portal port = (Portal) iter.next();
            if (port.getDirection() == dirChar) {     
                if (/*port.isLocked()*/ false) {
                    throw new InvalidCommandException("The portal in that direction is locked.");
                } else {
                    nextRoom = DM.mp.getSuccessor(currRoom, dirChar);
                    // check if room returned exists
                    if (nextRoom == null)
                        throw new InvalidCommandException("Error in MP: No room exists even though there's a portal.");
                    DM.cfm.setLocation(DM.playerId, nextRoom);
                    
                    // might have to remove the player from the mp module ?
                    
					playerJustMoved = true;
					previousRoom = currRoom;
                    // print info about the new room and what artifacts and creatures it contains
                    printFirstDescription();
                    return;
                }
            }
        }
        
        throw new InvalidCommandException("There is no portal in that direction - you cannot go there.");     
    }



    // from the command object, determines whether the monster (stored in object) can be attacked and
    // attack it if it can. The monster becomes angrified as soon as it is attacked.
    private void processAttack(InputCommand command) throws InvalidCommandException {
           
        if (command.toolExists()) //if tool exist, remind player to wield weapon first
            throw new InvalidCommandException("A tool is present in the command. Wield it first, "
                                              + "then write a command without the tool.");                                      
                                              
        String monsterName;
        if (!command.objectExists() || command.getObjectString() == "it")
            monsterName = "";
        else
            monsterName = command.getObjectString();
            
        UniqueId currRoom = DM.cfm.getLocation(DM.playerId);
        UniqueId targetMonsterId = null;
        ListIterator iter = (DM.mp.getCreatureList(currRoom)).listIterator();
        
        while (iter.hasNext()) {
            UniqueId monsterId = (UniqueId) iter.next();
            if (!monsterId.equals(DM.playerId)) {
	            if (monsterName.equals(DM.cfm.getShortName(monsterId).toLowerCase()) || monsterName == "") {
					if (DM.cfm.findCreature(monsterId).isAlive())
                        targetMonsterId = monsterId;						
        	  	    break;
                }
            }
        }

        Creature enemy = null;
		Creature play = null;    
	    if (targetMonsterId != null)
		  {
		    enemy = DM.cfm.findCreature(targetMonsterId);
            play = DM.cfm.findCreature(DM.playerId);  			
	      }

        if (targetMonsterId == null) {
            if (monsterName == "")
                throw new InvalidCommandException("There are no monsters in this room.");
            else
                throw new InvalidCommandException("The object " + monsterName + " you are trying to attack " +
                                                  "is either not here or it is dead.");
        } else {
            if (DM.cfm.isCreatureAlive(targetMonsterId)) {
				Random rand = new Random();
				
				if (enemy == null)
				   return;
				
				if (play == null)
				   return;
				
				enemy.modifyStrength((-1)*(Math.abs(rand.nextInt()%40)));  //take off 40 points from monster
				play.modifyStrength((-1)*(Math.abs(rand.nextInt()%40)));
                DM.cfm.makeMonsterAngry(targetMonsterId);
                System.out.println(DM.cfm.monsterAttacker(targetMonsterId));				
            } else {
                throw new InvalidCommandException("The monster " + monsterName + " is dead.");
            }
        }
		
		// print the new stats of the player and monster
		System.out.println ("Player Strength = "+play.getStrength());
		System.out.println ("Monster - "+ monsterName +" - Strength = "+enemy.getStrength());		
		
		if (enemy.isAlive() == false)
		  {
		    ((Player)(play)).modifyPoints(5); 
		    System.out.println ("You have successfully killed the "+ monsterName);
			
			System.out.println ("+5 points.");
			
		  }
		// If the creature is dead do we put its artifacts back in the room ?
        
    }

 

    // provides information with long descriptions of rooms, portals, artifacts and creatures
 	private void processInformation(InputCommand command) throws InvalidCommandException {
        
        // print desc of room and all portals
        if(!command.objectExists()) {
            printRoom();
            return;
        }
        
        String candidateObject = command.getObjectString();

        // print desc of one portal
        UniqueId currRoom = DM.cfm.getLocation(DM.playerId);
        String direction = candidateObject;
        char dirChar;
        
        //  find the direction
	    if 	(direction.equals("north") || direction.equals("n"))
            dirChar = 'n';
     		else if (direction.equals("south") || direction.equals("s"))
            dirChar = 's';
       	else if (direction.equals("west") || direction.equals("w"))
            dirChar = 'w';
		else if (direction.equals("east") || direction.equals("e"))
            dirChar = 'e';
		else
            dirChar = 'X';

        //  print info about the portal if the direction is supplied
        if (dirChar != 'X') { 
	
            List portalList = DM.mp.getPortalList(currRoom);
            ListIterator iter = portalList.listIterator();
        
            while(iter.hasNext()) {
                Portal port = (Portal) iter.next();
                if (port.getDirection() == dirChar) {
                    printPortal(port);
                    return;
                }
            }
            
            throw new InvalidCommandException("There's no portal in that direction.");
        }
        
        
        // check if object can be seen
        // didn't implement this, so for now can get information on all objects
        try
		{
		  ListIterator k = (DM.am.getCurrentList()).listIterator();
		  Artifact art;
		  String desc;
		  
		  while (k.hasNext())
		    {
			  art = (Artifact)(k.next());
			
			  if ((art.getShortName()).equals(command.object.getString()))
  		        System.out.println(desc = DM.am.getDescription(art.getObject()));			 
			}
	      
		  return;
		}
		catch( Exception e) {}
		
        // print the description of the room
        try{
		String desc = DM.mp.getDescription(currRoom);
            // here we are assuming that getDescription behaves as defined in the javadocs

        if ( desc == null ) 
            throw new InvalidCommandException("Can't understand the object '" 
                                               + candidateObject + "'.");
        System.out.println(desc);
		}
		catch (Exception e){}
    }



    // If command.object is valid, this function adds the artifact in the command to the list
    // of possessions of the player and removes the artifact from the map.
    private void processTake(InputCommand command) throws InvalidCommandException {
        
		if (!command.objectExists()) //if object doesn't exist throw exception
            throw new InvalidCommandException("No object in the take command present.");

		// make sure the object is in the room and find its UniqueId
        UniqueId currRoom = DM.cfm.getLocation(DM.playerId);
        List list = DM.mp.getArtifactList(currRoom);
		UniqueId id = objectInList(command.getObjectString(), list);
		if ( id == null )
			throw new InvalidCommandException("The artifact named " + command.getObjectString() +
											" is not in this room");

		// pick up the object
		if (DM.mp.removeMoveableObj(currRoom, id.getType(), id) == false)
			throw new InvalidCommandException("The artifact named " + command.getObjectString() +
											" cannot be picked.");
		DM.cfm.addArtifact(DM.playerId, id);
		System.out.println("Picked up the " + command.getObjectString() + ".");
    }



    // If command.object is valid, this function removes the artifact in the command from the list
    // of possessions of the player and adds the artifact to the current room in the map.
    private void processDrop(InputCommand command) throws InvalidCommandException {
        
		if (!command.objectExists()) //if object doesn't exist throw exception
            throw new InvalidCommandException("No object in the drop command present.");
        
		// make sure the object is in the players inventory and find its UniqueId
        UniqueId currRoom = DM.cfm.getLocation(DM.playerId);
        List list = DM.cfm.getArtifact(DM.playerId);
		UniqueId id = objectInList(command.getObjectString(), list);
		if ( id == null )
			throw new InvalidCommandException("The artifact named " + command.getObjectString() +
											" is not held by the player.");

		// leave the object in the room
		if ( DM.mp.addMoveableObj(currRoom, id.getType(), id) == false)
			throw new InvalidCommandException("The artifact named " + command.getObjectString() +
											" cannot be droped.");
		DM.cfm.removeArtifact(DM.playerId, id);
		System.out.println("Dropped the " + command.getObjectString() + ".");
    }



    // If command.object is valid, this function lists the artifacts in the 
    // of possessions of the player.
    private void processList(InputCommand command) throws InvalidCommandException {

		if (command.objectExists()) 
            throw new InvalidCommandException("The command 'list' can only be used without an object.");
		try
		{
		System.out.println( "Inventory:");
		}
		catch (Exception e)
		{
		System.out.println ("ERROR");
		}
		//print the artifacts
		List artifact_list = DM.cfm.getArtifact(DM.playerId);
		ListIterator iter = artifact_list.listIterator();
		UniqueId artifactId = null;
		while(iter.hasNext()) 
		{
			artifactId = (UniqueId) iter.next();
			try
			{
			System.out.println(DM.am.getName(artifactId));
			}
			catch (Exception e)
			{
			System.out.println ("ERROR");
			}
		}
		
		if (artifactId == null)
			System.out.println("[empty]");
	}



    // If command.object is valid, this function equips the player with the given weapon. 
    // The weapon must be in the inventory of the player.
    private void processWeild(InputCommand command) throws InvalidCommandException{
		if (!command.objectExists()) 
            throw new InvalidCommandException("The command wield must be used with an object.");
	
		// check the player is already holding the artifact to be weilded
        List list = DM.cfm.getArtifact(DM.playerId);
		UniqueId weaponId = objectInList(command.getObjectString(), list);
		if ( weaponId == null )
			throw new InvalidCommandException("Can not wield the artifact, " + command.getObjectString() +
											", because it is not held by the player.");
		// weild the weapon
		DM.cfm.wield(weaponId);
		try
		{			
		   System.out.println("The " + DM.am.getName(weaponId) + " has been wielded.");
		   System.out.println("Your strength has increased by 20%");
		}
		catch (Exception e)
		{
		System.out.println ("ERROR");
		}
	}



	// saves the game
	public void processSave(InputCommand command) throws InvalidCommandException {
		if (command.objectExists()) 
            throw new InvalidCommandException("The command save must not be used with an object.");

		// get the number for the saved game
		int saved_game_number = getSavedGameNumber();

	    // Create a directory for the saved game
		String saved_game_dir = "saved_games/" + String.valueOf(saved_game_number);
	    boolean success = (new File(saved_game_dir)).mkdir();
	    if (!success) 
            throw new InvalidCommandException("Save Failed: a directory with the number, "
				+ saved_game_number + ", already exists.");
		
		// save each of the majory CSCI's
			// there is nothing in the DM to save, except possibly the vocabulary, we are assuming this 
			//	will be inntialized the same way every time
/*		DM.mp.save(saved_game_dir + "/MP.dat");
		DM.am.save(saved_game_dir + "/AM.dat");
		DM.cfm.save(saved_game_dir + "/CFM.dat");
*/
	
		System.out.println("Save Successful\n"
			+ "Saved game #: " + saved_game_number );
	}



	// restores a saved game
	public void processRestore(InputCommand command) throws InvalidCommandException, IOException {
		if (command.objectExists()) 
            throw new InvalidCommandException("The command restore must not be used with an object.");

		
		// get the number of the saved game to restore
		int game_number;
		System.out.print("	Enter the saved game number to restore: ");
		BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));  
		try  {
			game_number = Integer.parseInt(stdin.readLine());
		} catch (NumberFormatException ex) {
            throw new InvalidCommandException("Could not restore because a number was not specified.");
		}

		// check that a saved game with that number exists
		int i;
		boolean game_exists = false;
		int next_game_number;
		File dir = new File("saved_games");
	    String[] games = dir.list();
		for (i = 0; i < games.length; i++)
		{
			next_game_number = Integer.parseInt(games[i]);
			if ( game_number == next_game_number )
				game_exists = true;
		}
		if (!game_exists)
            throw new InvalidCommandException("Could not restore because there isn't a saved game with that number.");

		// restore the game
		String saved_game_dir = "saved_games/" + String.valueOf(game_number);
/*		DM.mp.restore(saved_game_dir + "/MP.dat");
		DM.am.restore(saved_game_dir + "/AM.dat");
		DM.cfm.restore(saved_game_dir + "CFM.dat");
*/		
		System.out.println("Game restored.");
		printFirstDescription();
	}



	// 
	public void processScore(InputCommand command) throws InvalidCommandException {
		if (command.objectExists()) 
            throw new InvalidCommandException("The command score must not be used with an object.");
		
		System.out.println("\nYour SCORE is: " + DM.cfm.point_score() +"\n");
	}



	// prints a help message
	public void processHelp(InputCommand command) throws InvalidCommandException{
		if (command.objectExists()) 
            throw new InvalidCommandException("The command help must not be used with an object.");

		String help_str1, help_str2;
		help_str1 = "HELP\n"
			+ "\n"
			+ "To play the game you must type a command to make your character \n"
			+ "move.  Every command entered, must be of the form: \n"
			+ "	Verb [Object ['with' Tool]]\n"
			+ "where the []'s indicate optional parts of the command.  Note to use a tool,\n"
			+ "you must first provide the objects it operates on and the key word 'with'.\n"
			+ "Examples of verbs and objects are listed below.\n\n";
		System.out.print(help_str1);
		vocab.printVocabulary();
		help_str2 = "Examples of valid commands include:\n"
			+ "	look\n"
			+ "	attack it\n"
			+ "	move south\n"
			+ "	hit nail with hammer\n"
			+ "\n"
			+ "You can also type the following system commands:\n"
			+ "save, restore, score, help and exit.\n\n";
		System.out.print(help_str2);
	}



	// exits the game
	public void processExit(InputCommand command) throws InvalidCommandException {
		if (command.objectExists()) 
            throw new InvalidCommandException("The command exit must not be used with an object.");
		System.out.println("\n==========================");
		System.out.println("Thank-you for playing DAG!");
		System.out.println("==========================");
		System.exit(0);
	}



	// performs an action which is not defined by the DM
    private void processNonDMAction(InputCommand command) throws InvalidCommandException{
		UniqueId objectId;
		UniqueId toolId = null;
		boolean action_supported = false;

		// check command to make sure it has the proper structure
		if (!command.objectExists()) 
            throw new InvalidCommandException("The action, " + command.getVerbString() 
				+ ", must be used with an object.");
		
		// check that the object and tool are in the players inventory
        List inventory = DM.cfm.getArtifact(DM.playerId);		
		objectId = objectInList(command.getObjectString(), inventory);
		
		if (objectId == null)
		  {
		    //get the inventory in the room					
			inventory =DM.mp.getArtifactList(((MoveableObject)(DM.cfm.creatures.get(0))).getLocation());
     		objectId = objectInList(command.getObjectString(), inventory);
			
		  }
		
		if (objectId == null) 
		try
		{
            throw new InvalidCommandException("Can not perform the action because the object, " 
				+ command.getObjectString() + ", is not in "
				+ DM.am.getName(DM.playerId) + "'s inventory.");
		}
		catch (Exception e)
		{
		System.out.println ("ERROR1");
		}
  	
		if ( command.toolExists()) {
			toolId = objectInList(command.getToolString(), inventory);
			if (toolId == null) 
    		try
			{
		        throw new InvalidCommandException("Can not perform the action because the tool, " 
					+ command.getObjectString() + ", is not in "
					+ DM.am.getName(DM.playerId) + "'s inventory.");
			}
			catch (Exception e)
			{
			System.out.println ("ERROR2");
			}
		}
		
		// check that the action is supported
		if ( toolId == null) 
		try
		{	
			action_supported = DM.am.artifactActionCheck(objectId, command.getVerbString());
		}
		catch (Exception e)
		{
		System.out.println ("ERROR3");
		}
		else
		try{
			action_supported = DM.am.toolActionCheck(toolId, command.getVerbString(),objectId);
		}
		catch (Exception e)
		{
		System.out.println ("ERROR4");
		}
		if ( action_supported == false)
            throw new InvalidCommandException("This action is undefined.");
			
		// perform the action
	try
	{
		if ( DM.am.artifactActionUpdate(objectId, command.getVerbString()) == false) {
			// remove the artifact because if it was destroyed
			DM.cfm.removeArtifact(DM.playerId, objectId);
			DM.mp.removeMoveableObj(((MoveableObject)(DM.cfm.creatures.get(0))).getLocation(), 'a', objectId);
		}
	}
	catch (Exception e)
	{
	System.out.println ("ERROR");
	}	

		if (DM.am.getArtifactType(objectId).equals("food") && (command.getVerbString().equals("eat") ||command.getVerbString().equals("drink")))
		  {
		    System.out.println("The "+ DM.am.getArtifactType(objectId)+" was devoured.");
			DM.mp.removeMoveableObj(((MoveableObject)(DM.cfm.creatures.get(0))).getLocation(), 'a',objectId );
			((Player)(DM.cfm.creatures.get(0))).modifyStrength(30);
			System.out.println ("Your total life points has increased by 30 to " +((Player)(DM.cfm.creatures.get(0))).getStrength());
		  }
/*
		if (DM.am.getArtifactType(ObjectId).equals("weapon"))
		  {
		    System.out.println("The "+ DM.am.getArtifactType(ObjectId).getShortName()+" was eaten");
		  }
		if (DM.am.getArtifactType(ObjectId).equals("food"))
		  {
		    System.out.println("The "+ DM.am.getArtifactType(ObjectId).getShortName()+" was eaten");
		  }
*/
	}


    void processHealth(InputCommand command)
	  {
		System.out.println ("Your total life points is " +((Player)(DM.cfm.creatures.get(0))).getStrength());	    
	  }



	//______________________________ Other helper functions ______________________
	
    // returns the uid if the objectStr corresponds to one of the UniqueId's in the list
    //  of movable objects.  Returns null if it not in the list
    private UniqueId objectInList(String objectStr, List moveableUidList) {
        ListIterator iter = moveableUidList.listIterator();
        UniqueId nextUid = null;
        while (iter.hasNext()) {
            nextUid = (UniqueId) iter.next();
			try{
			
            if ( objectStr.equalsIgnoreCase(DM.am.getName(nextUid)) )
                return nextUid;
			}
			catch (Exception e)
			{
			System.out.println ("ERROR");
			}
        }
        return null;
    }



    // prints all the artifacts and monsters present in the current room
    private void printArtifactsAndCreatures() {
        UniqueId currRoom = DM.cfm.getLocation(DM.playerId);
        
        // print all the short names of the artifacts in the current room
        List list = DM.mp.getArtifactList(currRoom);
        ListIterator iter = list.listIterator();
        System.out.println("\nArtifacts present:");
        System.out.println("------------------");
        while(iter.hasNext()) {
            UniqueId id = (UniqueId) iter.next();
        try
		{
		    System.out.println(DM.am.getName(id));
		}
		catch (Exception e)
		{
		System.out.println ("ERROR");
		}
        }
        
        // print all the short names of the monsters in the current room
        list = DM.mp.getCreatureList(currRoom);
        iter = list.listIterator();
        System.out.println("\nCreatures present:");
        System.out.println("------------------");
        while(iter.hasNext()) {
            UniqueId id = (UniqueId) iter.next();
            if (!id.equals(DM.playerId))
                System.out.println(DM.cfm.getShortName(id));
        }
	System.out.println("");
    }



    // prints the description of the current room + portals
    private void printRoom() {	
        UniqueId currRoom = DM.cfm.getLocation(DM.playerId);
	  System.out.println("\n= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =");
	  System.out.println("= * * * * * * * * * *   N E X T   T U R N   * * * * * * * * * =");
	  System.out.println("= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n");

        System.out.println("Room Description: ");
        System.out.println("----------------- ");
        System.out.println(DM.mp.getDescription(currRoom));

        //printing portals
        List portals = DM.mp.getPortalList(currRoom);
        ListIterator iter = portals.listIterator();

		System.out.println("\nPortals to different rooms:");
		System.out.println(  "---------------------------");

        while (iter.hasNext()) {
            Portal p = (Portal)(iter.next());
            printPortal(p);
        }
		
        printArtifactsAndCreatures();
		System.out.println("");
    }




    // prints a portal's description and direction
    private void printPortal(Portal p) {
	String description;
        String direction;
        char dir;
  
        // get the string for the direction
        dir = p.getDirection();
        if (dir == 'n' || dir == 'N') {
            direction = "North";
        } else if (dir == 's' || dir == 'S') {
            direction = "South";
        } else if (dir == 'w' || dir == 'W') {
            direction = "West ";
        } else if (dir == 'e' || dir == 'E') {
            direction = "East ";
        } else {
            return;
        }    
	description = p.getDescription();

	if (description != "") {
        System.out.println(direction + " : " + description); 
      }
    }


	// finds a number (corresponding to a directory name) for the next saved game
	private int getSavedGameNumber()
	{
		// get the list of dir names corresponding the the numbers of the saved
		// 	games
		File dir = new File("saved_games");
	    String[] games = dir.list();
		
		// find the game number for the game we are about to save
		//	This number will be the biggest directory number plus one
		int i;
		int next_game_number;
		int max_game_number = 0;
		for (i = 0; i < games.length; i++)
		{
			next_game_number = Integer.parseInt(games[i]);
			if ( next_game_number > max_game_number )
				max_game_number = next_game_number;

		}

		return max_game_number + 1;
	}

	
} 
