import java.util.*;
import java.io.*;

// if the portal's id is negative, it means it's not active!
class Portal implements Serializable
  {
    public UniqueId id;        // unique id.
    public String description;   // description.

    public int direction;    //0-north,1-east, 2-south,3-west
    public UniqueId successorid;      //id number of successor room, if -1, there's no room successor
    public boolean is_locked;

    private static int nextportalid=0; //holds the id of the next portal created

    public void initportal(String intext, int dir, UniqueId successor)
      {
        id = new UniqueId(nextportalid++, 'p'); //give a unique id to the portal.
  
        description = intext;  // save a copy of the input text

        // the user must ensure that the direction is correct.       
        if (dir >=0 && dir <= 3)
          {
            direction = dir;
          }

        successorid = successor; //the user must ensure the succorid is valid
      }  

    public Portal()
      {
        this.id = new UniqueId(-1,'p');
	this.description = "";
      }
    
    public Portal(UniqueId new_uid, String description, int direction)
      {
        this.id = new_uid;
	this.description = description;
	this.direction = direction;
      }

	public boolean isLocked () {
		return is_locked;
	}

     void setIsLocked(boolean is_locked) {
        this.is_locked = is_locked;
     }

     void setDirection(char dir) {
	    if (dir == 'n')
		  {
		    direction = 0;
		  }
	    else if (dir == 'e')
		  {
		    direction = 1;
		  }
	    else if (dir == 's')
		  {
		    direction = 2;
		  }
	    else 
		  {
		    direction = 3;
		  }
		
     }
     
     void setSuccessor(UniqueId successor)  {
     }

     public char getDirection() {
	    if (direction == 0)
		  {
		    return 'n';
		  }
	    else if (direction == 1)
		  {
		    return 'e';
		  }
	    else if (direction == 2)
		  {
		    return 's';
		  }
	    else 
		  {
		    return 'w';
		  }
        
     }
	 
   public UniqueId getUid()
     {
       return this.id;
     }
   
   public void setUid(UniqueId new_uid)
     {
       this.id = new_uid;
     }

   public String getDescription()
     {
       return description;
     }

   public void setDescription(String desc)
     {
       this.description = desc;
     }

  }
