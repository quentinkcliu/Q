//package am;

import java.util.List;

/**
 * @author Igor Keizner
 */
public class Thing extends Artifact 
{
	/**
	 * Constructor for Thing.
	 */
	public Thing() 
	{
		super();
	}

	/**
	 * Constructor for Thing.
	 * @param new_uid
	 * @param description
	 * @param shortName
	 * @param location
	 * @param strength
	 * @param usage
	 * @param actions
	 */
	public Thing(UniqueId new_uid,
 		          String description,
		          String shortName,
 		          UniqueId location,
		          int strength,
		          int usage,
		          List actions) 
    {
		super(new_uid, description, shortName, location, strength, usage, actions);
	}
}