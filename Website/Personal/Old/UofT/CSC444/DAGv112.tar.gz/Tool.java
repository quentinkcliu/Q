//package am;

import java.util.*;

/**
 * @author Igor Keizner
 */
public class Tool extends Artifact 
{
	private List usageClass;
	private List usageObjects;	
	
	/**
	 * Constructor for Tool.
	 */
	public Tool() 
	{
		super();
		this.usageClass = null;
		this.usageObjects = null;
	}

	/**
	 * Constructor for Tool.
	 * @param new_uid
	 * @param description
	 * @param shortName
	 * @param location
	 * @param strength
	 * @param usage
	 * @param actions
	 */
	public Tool(UniqueId new_uid,
		         String description,
		         String shortName,
		         UniqueId location,
		         int strength,
		         int usage,
		         List actions,
		         List usageClass,
		         List usageObjects) 
    {
		super(new_uid, description, shortName, location, strength, usage, actions);
		
		this.usageClass = usageClass;
		this.usageObjects = usageObjects;
	}
}