//package am;

import java.util.List;

/**
 * @author Igor Keizner
 */
public class Treasure extends Artifact 
{
	/**
	 * Constructor for Treasure.
	 */
	public Treasure() 
	{
		super();
	}

	/**
	 * Constructor for Treasure.
	 * @param new_uid
	 * @param description
	 * @param shortName
	 * @param location
	 * @param strength
	 * @param usage
	 * @param actions
	 */
	public Treasure (UniqueId new_uid,
 		              String description,
		              String shortName,
 		              UniqueId location,
		              int strength,
		              int usage,
		              List actions) 
    {
		super(new_uid, description, shortName, location, strength, usage, actions);
	}
}