class UniqueId{
   // variable

   // one of the object type's id
   private long uid;

   // character represents the type of object. 'r' stands for room
   // 'c' stands for creature, and 'a' stands for artifact, 'p' stands for portal
   private char type;
   
   // method

   public UniqueId()
     {

     }
 
   public UniqueId(long uid, char type)
     {
       this.uid = uid;
       this.type = type;
     }
  
   // to get/set uid and class type
   public void setUid(long uid) 
     {
       this.uid = uid;
     }
     
   public void setType(char type)
     {
       this.type = type;
     }

   public long getUid()
     {
       return uid;
     }

   public char getType()
     {
       return type;
     }
   
   // return true if two unique ids are same
   public boolean equals(UniqueId comp_uid)
     {
       if (comp_uid == null){
	   		return false;
		}
	   if (this.uid == comp_uid.getUid())
         {
           return true;
         }
       else
         {
           return false;
         }
     }

   // return true if the id is corresponding type
   public boolean isArtifact()
     {
       if (type == 'a' || type == 'A')
         return true;
       else
         return false;
     }

   public boolean isCreature()
     {
       if (type == 'c' || type == 'C')
         return true;
       else
         return false;
     }

   public boolean isRoom()
     {
       if (type == 'r' || type == 'R')
         return true;
       else
         return false;
     }

   public boolean isPortal()
     {
       if (type == 'p' || type == 'P')
         return true;
       else
         return false;
     }
   
}

