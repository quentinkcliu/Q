/* DATA ABSTRACTION	- Vocabulary

Description: Defines the vocabulary that is available to assemble user commands.
*/

import java.util.*;
import java.lang.reflect.*;
import java.security.*;
import java.io.*;

public class Vocabulary
{

	private Hashtable VerbHashTable;
	private Hashtable ObjectHashTable;



	/*_____________________ Primative Constructors ________________________________*/


	/*	Procedural Definition
		Name:		Vocabulary
		Parameters:	- DMVerbs - a list of the verbs defined by the DM CSCI
					- DMObjects - a list of objects defined by the DM.  Note the
						definition object here is the gramatical one, not the class
						in the game specs.
					- actions - a complete list of action words used for all
						artifacts in the game
					- moveableObjects - a list of all moveable objects in the game
		Requires:	- each string must meet the requirements of a VocabularyItem
					- no string can contain the key word 'with'
					- no conflicts between items in the vocabulary. In other words:
						- no string can contain the key word 'with'
						- the string hasn't already been defined by the DM
						(duplicates defined by other modules are thrown out.)
						- one verb/action can not be a subset of words at the start
							of another verb/action
		Effects:	- creates the vocabulary from the strings in the input arrays,
						where should be one item in the vocabulary
		Modifies:	- modfies the private variables
		Raises:		- throws an InstantiationError if the conditions in the requires
						clause are not met
	*/
	public Vocabulary 
		( String[] DMVerbs, String[] DMObjects,
			String[] actions, String[] moveableObjects )
	{
		// create the hashtables to store the verbs and objects 
		VerbHashTable = new Hashtable();
		ObjectHashTable = new Hashtable();

		// add the given items to the appropriate hashtable
		addStringsToVocab (DMVerbs, VerbHashTable, true, true);
		addStringsToVocab (DMObjects, ObjectHashTable, true, false);
		addStringsToVocab (actions, VerbHashTable, false, true);
		addStringsToVocab (moveableObjects, ObjectHashTable, false, false);
		
	}




	/*_____________________ Constructors __________________________________________*/

	//none



	/*_____________________ Mutators ______________________________________________*/

	//none
	
	

	/*_____________________ Observers _____________________________________________*/


	/*	Procedural Definition
		Name:		findVerb
		Parameters:	- cadidate - the string to be checked
		Effects:	- checks to see if the candidate is a verb (it is in the
						list of DM verbs or in the list of actions)
					- returns the vocabulary item corresponding to the candidate if
						the candidate is a verb defined in the vocabulary
					- returns null if the candidate is not a verb in the vocabulary
		Raises:		
	*/
	public VocabularyItem findVerb(String candidate) 
	{		
		return findCandidateInHashtable (candidate, VerbHashTable);
	} 



	/*	Procedural Definition
		Name:		findObject
		Parameters:	- candidate - the string to be checked
		Effects:	- checks to see if the candidate is an object in the vocabulary
					- returns the vocabulary item corresponding to the candidate if
						the candidate is an object defined in the vocabulary
					- returns null if the candidate is not an object in the
						vocabulary
		Raises:		
	*/
	public VocabularyItem findObject(String candidate) 
	{
		return findCandidateInHashtable (candidate, ObjectHashTable);
	}



	/*	Procedural Definition
		Name:		findTool
		Parameters:	- candidate - the string to be checked
		Effects:	- checks to see if the candidate could be a tool (it is an object
						that is not defined by the DM)
					- returns the vocabulary item corresponding to the candidate if
						the candidate could be a tool 
					- returns null if the candidate can not be a tool
		Raises:		
	*/
	public VocabularyItem findTool(String candidate)
	{
		VocabularyItem tool;	
		tool = findCandidateInHashtable (candidate, ObjectHashTable);

		// determine if a tool was returned.  Recall that the DM can not define any
		//	tools
		if ( tool == null || tool.isDefinedByDM() == true )
			return null;
		
		return tool;
	} 



	// prints the vocabulary
	public void printVocabulary()
	{
		String str;
		str = "Verbs:\n";
		Enumeration ht_verbs = VerbHashTable.keys();
		String verb;			
		while (ht_verbs.hasMoreElements())
		{
			verb = "	" + (String) ht_verbs.nextElement() + "\n";
			str = str.concat(verb);
		}
		str = str.concat("\nOjects:\n");
		Enumeration ht_objects = ObjectHashTable.keys();
		String object;			
		while (ht_objects.hasMoreElements())
		{
			object = "	" + (String) ht_objects.nextElement() + "\n";
			str = str.concat(object);
		}
		str = str.concat
			("\nNote: All tools are in the list of objects, but not all of the objects\n"
			+ "are tools.\n\n");
		System.out.print(str);
	}



	/* _________________________ helper functions ________________________________ */


	/*	Procedural Definition
		Name:		addStringsToVocab
		Parameters:	- strs - an array of strings
					- ht - a hashtable
					- strs_defined_by_DM - true if the strings were defined by the
						DM, false if defined by another CSCI
					- check_prefix_condition - if true check that one item is not a
						subset of words at the start of another item 
		Requires:	- the argument ht can not be null
					- the prefix condition should only be set to true if for
						verbs/actions
					- the strings to meet all the conditions in the requires clause
						of the constructor
		Effects:	- creates a vocabulary item for each string 
					- add the vocabulary items to the hashtable 
		Modifies:	- modfies the private variables specified by ht.
		Raises:		- throws an InvalidParameterException if the conditions in the
						requires clause are not met
					- throws and InstatiationError if the requires clause of the
						constructor is not met
	*/
	private void addStringsToVocab (String[] strs, Hashtable ht, 
		boolean strs_defined_by_DM, boolean check_prefix_condition )
	{
		int num_of_strs;
		String new_str;
	
		//validate inputs
		if (strs == null)
			return;
		if (ht == null)
			throw new InvalidParameterException
				("Illegal call to addStringsToVocab; The input vocab can not be null.");
		if ( check_prefix_condition && ht != VerbHashTable )
			throw new InvalidParameterException
				("Illegal call to addStringsToVocab; the prefix condition can only "
					+ "be set to true when adding items to the VerbHashTable.");

		// add the strings to the vocab 
		num_of_strs = Array.getLength(strs);
	
		for (int i = 0; i < num_of_strs; i++)
		{
			new_str = clean(strs[i]);
			checkItem (new_str, ht, check_prefix_condition);
			  
			// add the item to the vocabulary list
			VocabularyItem new_vi = new VocabularyItem(new_str, strs_defined_by_DM);			
			ht.put(new_str ,new_vi);		// if it was already there don't worry about it
		}
	}



	/*	Procedural Definition
		Name:		checkItem
		Parameters:	- str - string want to add to the hash table
					- ht - the hashtable
					- check_prefix_condition - if true check that the item can not be
						subset of words at the start of another item (and vice versa)
		Requires:	- all the conditions that addStringsToVocab and the constructur
						require 
					- can only be called by addStringsToVocab (becasue I haven't
						written the code to check the above conditions)
		Effects:	- confirms an item can be added to the vocabulary 
					- creates a vocabulary item for the string 
					- add the item to the hashtable 
		Modifies:	- adds the item to the ht.
		Raises:		- throws and InstatiationError if the requires clause of the
						constructor is not met
	*/
	private void checkItem (String str, Hashtable ht, boolean check_prefix_condition)
	{
		StringTokenizer st;
		String next_token;
			
		//check it doesn't contain the key word 'with'
		st = new StringTokenizer(str);
		while (st.hasMoreTokens())
		{
			next_token = st.nextToken();
			if ( next_token.equals("with") )
			{
				throw new InstantiationError("ERROR: The vocabulary could not be"
					+ " created because the vocabulary item '" + str + "' contains"
					+ " the key word 'with'." );
			}
		}	
			
		// make sure the item hasn't already been defined by the DM 
		if ( ht.containsKey(str) 
			&& ((VocabularyItem) ht.get(str)).isDefinedByDM() )
		{
			throw new InstantiationError("ERROR: The vocabulary could not be created because"
				+ " the vocabulary item '" + str + "' has already been defined by the DM"
				+ " and it can not be used again." );
		}

		// make sure one string is not a substring at the start of another in the existing vocab
		if (check_prefix_condition == true)
		{
			Enumeration ht_items = ht.keys();
			String ht_item;
			
			while (ht_items.hasMoreElements())
			{
				ht_item = (String) ht_items.nextElement();
				if ( ! ht_item.equals(str)
					&& (// elimante it if the str is a subet of words at the start of an item
						//	 already in the hash table 
						ht_item.startsWith(str.concat(" ")) 
								//need space so it is a subset of words and not just characters
						// elimante it if an item already in the hashtable is a substring at
						//	at the start of str
						|| str.startsWith(ht_item.concat(" ")) ) )
				{
					throw new InstantiationError("ERROR: The vocabulary could not be created because"
						+ " there is conflict between the verbs '" + str
						+ "' and '" + ht_item + "'.  One verb is substring of the other.");
				}
			}			
		}
	}




	/*	Procedural Definition
		Name:		clean
		Parameters:	- dirty_str - the string to be cleaned
		Effects:	- cleans a string by 
						- trimming the whitespace off the ends
						- making sure there is a single space between each word 
						- making the string lower case
					- returns null if the string is null
		Raises:		
	*/
	private static String clean (String dirty_str)
	{
		StringTokenizer st;
		String clean_str;
		
		// validate inputs
		if (dirty_str == null)
			return null;

		// go ahead and clean the string
		st = new StringTokenizer(dirty_str);

		if ( ! st.hasMoreTokens() )
			return "";
		clean_str = st.nextToken();	
		while (st.hasMoreTokens())
		{
			clean_str = clean_str.concat(" ");
			clean_str = clean_str.concat(st.nextToken());
		}			
		
		clean_str = clean_str.toLowerCase();
		return clean_str;
	}




	/*	Procedural Definition
		Name:		findCandidateInHashtable
		Parameters:	- candidate - the string to be checked
					- ht - hashtable to check for string in
		Effects:	- checks to see if the candidate is mapped in the hashtable
					- returns the vocabulary item corresponding to the candidate if
						the candidate is mapped in the hashtable
					- returns null if the candidate is not mapped in the hashtable
		Raises:		- throws an InvalidParameterException if the input paramets are
						null*/
	private VocabularyItem findCandidateInHashtable (String candidate, Hashtable ht) 
	{
		// validate inputs
		if (candidate == null) 
			return null;
		if (ht == null)
			throw new InvalidParameterException
				("Illegal call to VocabularyItem; The input ht cannot be null.");

		// find the canditate
		candidate = clean(candidate);
		if ( candidate.equals("") )
			return null;
		return (VocabularyItem) ht.get(candidate);
	}



}



