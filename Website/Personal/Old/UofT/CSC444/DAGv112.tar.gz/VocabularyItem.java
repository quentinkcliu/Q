/* DATA ABSTRACTION	- VocabularyItem

Description: The class stores one item in the vocabulary. For example 'attack'
				and 'red gem' are two instances of VocabularyItem.
*/

public class VocabularyItem 
{

	String text;
	boolean is_defined_by_DM;



	/*_____________________ Primative Constructors ________________________________*/


	/*	Procedural Definition
		Name:		VocabularyItem
		Parameters:	- text - contains the text for the item eg 'red gem' 
					- is_defined_by_DM - set it to true if the item was defined by
						the DM CSCI, false if it was defined by another CSCI.
		Requires:	- the input parameter text to:
							- be non-null
							- contain alpha numeric characters
		Effects:	- creates one item in the vocabulary
		Modifies:	- the private variables
		Raises:		- throws an InstantiationError if the conditions in the requires
						claurse are not met
	*/
	public VocabularyItem(String text, boolean is_defined_by_DM)
	{
		// make sure the neccessary inputs are provided
		if ( text == null )
			throw new InstantiationError("Can't create the vocabulary item."
				+ "  The input txt can not be null.");
		
		// make the the text contains alpha-numberic characters 
		if ( (text.trim()).equals("") )
		{
			throw new InstantiationError("Can't create the vocabulary item."
				+ "  Every item must contain alpha-numeric characters.");
		}

		// it is a valid vocabulary item so create it
		this.text = text;
		this.is_defined_by_DM = is_defined_by_DM;

	}




	/*_____________________ Constructors __________________________________________*/

	//none



	/*_____________________ Mutators ______________________________________________*/

	//none
	
	

	/*_____________________ Observers _____________________________________________*/


	/*	Procedural Definition
		Name:		getString
		Parameters:	
		Effects:	- returns the text of the vocabulary item.
		Raises:		
	*/
	public String getString ()
	{
		return text;
	}
	
	
	
	/*	Procedural Definition
		Name:		isDefinedByDM
		Parameters:	
		Effects:	- returns true when the item was defined by the DM 
					- returns false if the vocab item was defined by another CSI
		Raises:		
	*/
	public boolean isDefinedByDM ()
	{
		return is_defined_by_DM;
	}


}


