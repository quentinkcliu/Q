//package am;

import java.util.List;

/**
 * @author Igor Keizner
 */
public class Weapon extends Artifact 
{	
	/**
	 * Constructor for Weapon.
	 */
	public Weapon() 
	{
		super();
	}

	/**
	 * Constructor for Weapon.
	 * @param new_uid
	 * @param description
	 * @param shortName
	 * @param location
	 * @param strength
	 * @param usage
	 * @param actions
	 */
	public Weapon(
		UniqueId new_uid,
		String description,
		String shortName,
		UniqueId location,
		int strength,
		int usage,
		List actions) 
	{
		super(new_uid, description, shortName, location, strength, usage, actions);
	}
}